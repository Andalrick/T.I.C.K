#!/usr/bin/env python3
"""
Module pour télécharger les artworks de jeux depuis SteamGridDB
Utilise le wrapper officiel python-steamgriddb
"""
import os
from pathlib import Path
from typing import Optional, Dict
import requests

# Essayer d'importer le wrapper officiel
try:
    from steamgrid import SteamGridDB as OfficialSteamGridDB
    OFFICIAL_WRAPPER_AVAILABLE = True
except ImportError:
    OFFICIAL_WRAPPER_AVAILABLE = False
    OfficialSteamGridDB = None


class SteamArtworkManager:
    """Gère le téléchargement et l'installation des artworks pour Steam"""
    
    def __init__(self, api_key: str = None):
        if not OFFICIAL_WRAPPER_AVAILABLE:
            raise ImportError(
                "Le wrapper python-steamgriddb n'est pas installé.\n"
                "Installez-le avec: pip install --break-system-packages python-steamgriddb"
            )
        
        self.api_key = api_key
        self.client = OfficialSteamGridDB(api_key) if api_key else None
        self.steam_path = self._find_steam_path()
        self.grid_path = None
        
        if self.steam_path:
            self.grid_path = self._find_grid_path()
    
    def _find_steam_path(self) -> Optional[Path]:
        """Trouve le chemin d'installation de Steam"""
        candidates = [
            Path.home() / ".steam" / "steam",
            Path.home() / ".local" / "share" / "Steam",
            Path.home() / ".var" / "app" / "com.valvesoftware.Steam" / ".local" / "share" / "Steam",
        ]
        
        for path in candidates:
            if path.exists() and (path / "steamapps").exists():
                return path
        
        return None
    
    def _find_grid_path(self) -> Optional[Path]:
        """Trouve le dossier grid pour les artworks"""
        if not self.steam_path:
            return None
        
        userdata_path = self.steam_path / "userdata"
        if not userdata_path.exists():
            return None
        
        # Chercher le premier utilisateur
        for user_dir in userdata_path.iterdir():
            if user_dir.is_dir() and user_dir.name.isdigit():
                grid_dir = user_dir / "config" / "grid"
                grid_dir.mkdir(parents=True, exist_ok=True)
                return grid_dir
        
        return None
    
    def is_available(self) -> bool:
        """Vérifie si Steam est disponible"""
        return (self.steam_path is not None and 
                self.grid_path is not None and 
                self.client is not None)
    
    def download_all_artwork(self, game_name: str, steam_appid_nonsteam: int, 
                            prefer_logo: bool = True) -> Dict[str, bool]:
        """
        Télécharge tous les artworks pour un jeu
        
        Args:
            game_name: Nom du jeu
            steam_appid_nonsteam: AppID généré par Steam pour le jeu non-Steam
            prefer_logo: Préférer les grids avec logo
        
        Returns:
            Dictionnaire {type: succès} (grid, hero, logo, icon)
        """
        if not self.is_available():
            print("[SteamArtwork] Steam non disponible ou pas de clé API")
            return {}
        
        # Rechercher le jeu sur SteamGridDB
        print(f"[SteamArtwork] Recherche: {game_name}")
        
        try:
            results = self.client.search_game(game_name)
            
            if not results or len(results) == 0:
                print(f"[SteamArtwork] Jeu non trouvé: {game_name}")
                return {}
            
            # Prendre le premier résultat
            game = results[0]
            game_id = game.id
            print(f"[SteamArtwork] ✓ Trouvé: {game.name} (ID: {game_id})")
            
            results_dict = {}
            
            # 1. Grid (portrait 600×900)
            try:
                grids = self.client.get_grids_by_gameid([game_id])
                
                if grids:
                    # Filtrer pour avoir un logo si demandé
                    if prefer_logo:
                        try:
                            # Essayer d'exclure NSFW et no_logo
                            grids_with_logo = [g for g in grids if "no_logo" not in str(getattr(g, 'style', '')).lower()]
                            if grids_with_logo:
                                grids = grids_with_logo
                        except:
                            pass  # Si erreur, prendre tous les grids
                    
                    grid_url = grids[0].url
                    grid_path = self.grid_path / f"{steam_appid_nonsteam}p.jpg"
                    results_dict["grid"] = self._download_image(grid_url, str(grid_path))
            except Exception as e:
                print(f"[SteamArtwork] Erreur grids: {e}")
            
            # 2. Hero (bannière large 1920×620)
            try:
                heroes = self.client.get_heroes_by_gameid([game_id])
                if heroes:
                    hero_url = heroes[0].url
                    hero_path = self.grid_path / f"{steam_appid_nonsteam}_hero.jpg"
                    results_dict["hero"] = self._download_image(hero_url, str(hero_path))
            except Exception as e:
                print(f"[SteamArtwork] Erreur heroes: {e}")
            
            # 3. Logo (PNG transparent)
            try:
                logos = self.client.get_logos_by_gameid([game_id])
                if logos:
                    logo_url = logos[0].url
                    logo_path = self.grid_path / f"{steam_appid_nonsteam}_logo.png"
                    results_dict["logo"] = self._download_image(logo_url, str(logo_path))
            except Exception as e:
                print(f"[SteamArtwork] Erreur logos: {e}")
            
            # 4. Icon (256×256)
            try:
                icons = self.client.get_icons_by_gameid([game_id])
                if icons:
                    icon_url = icons[0].url
                    icon_path = self.grid_path / f"{steam_appid_nonsteam}.jpg"
                    results_dict["icon"] = self._download_image(icon_url, str(icon_path))
            except Exception as e:
                print(f"[SteamArtwork] Erreur icons: {e}")
            
            success_count = sum(1 for v in results_dict.values() if v)
            print(f"[SteamArtwork] ✓ {success_count}/{len(results_dict)} artwork(s) téléchargé(s)")
            
            return results_dict
        
        except Exception as e:
            print(f"[SteamArtwork] Erreur: {e}")
            import traceback
            traceback.print_exc()
            return {}
    
    def _download_image(self, url: str, output_path: str) -> bool:
        """Télécharge une image"""
        try:
            response = requests.get(url, timeout=30, stream=True)
            response.raise_for_status()
            
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            
            with open(output_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            print(f"[SteamArtwork] ✓ Téléchargé: {Path(output_path).name}")
            return True
        
        except Exception as e:
            print(f"[SteamArtwork] Erreur téléchargement {Path(output_path).name}: {e}")
            return False


def get_api_key_instructions() -> str:
    """Instructions pour obtenir une clé API SteamGridDB"""
    return """
Pour télécharger les artworks depuis SteamGridDB :

1. Créer un compte gratuit sur https://www.steamgriddb.com
2. Aller dans Preferences → API
3. Générer une clé API
4. Copier la clé et la coller dans T.I.C.K

La clé API est gratuite et permet 100 requêtes par jour.

Installation du wrapper:
  pip install --break-system-packages python-steamgriddb
"""


# Test du module
if __name__ == "__main__":
    import sys
    
    if not OFFICIAL_WRAPPER_AVAILABLE:
        print("✗ python-steamgriddb n'est pas installé!")
        print(get_api_key_instructions())
        sys.exit(1)
    
    if len(sys.argv) < 2:
        print("Usage: python steam_artwork.py <API_KEY> [game_name]")
        print(get_api_key_instructions())
        sys.exit(1)
    
    api_key = sys.argv[1]
    game_name = sys.argv[2] if len(sys.argv) > 2 else "Rayman Legends"
    
    manager = SteamArtworkManager(api_key)
    
    if not manager.is_available():
        print("❌ Steam non disponible!")
        sys.exit(1)
    
    print(f"✓ Steam trouvé: {manager.steam_path}")
    print(f"✓ Grid path: {manager.grid_path}")
    
    # Test avec un AppID fictif
    fake_app_id = 3999999999  # ID très haut pour éviter les conflits
    
    print(f"\nTest de téléchargement pour '{game_name}'...")
    results = manager.download_all_artwork(game_name, fake_app_id)
    
    print("\nRésultats:")
    for art_type, success in results.items():
        status = "✓" if success else "✗"
        print(f"  {status} {art_type}")
