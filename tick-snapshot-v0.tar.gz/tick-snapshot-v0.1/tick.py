#!/usr/bin/env python3
import os
import re
import stat
import shutil
import subprocess
import threading
import sqlite3
import struct
import zlib
import tempfile
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict

from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QPushButton, QLineEdit, QFileDialog, QMessageBox, QComboBox,
    QTextEdit, QLabel, QCheckBox, QGroupBox, QTableWidget, QTableWidgetItem,
    QHeaderView, QTabWidget, QProgressDialog, QMenu, QInputDialog, QRadioButton
)
from PySide6.QtGui import (
    QGuiApplication, QPixmap, QIcon, QPainter, QFont, QColor
)
from PySide6.QtCore import Qt, QTimer, QRect, QSize

# Tout est intégré dans ce fichier
STEAM_SUPPORT = True
ICON_EXTRACTION_SUPPORT = True

# Import du module artworks (optionnel)
try:
    from steam_artwork import SteamArtworkManager
    ARTWORK_SUPPORT = True
except ImportError:
    ARTWORK_SUPPORT = False
    SteamArtworkManager = None


# ---------------------------
# Paths / assets (dev + rpm)
# ---------------------------

DEFAULT_OUTDIR = os.path.expanduser("~/.local/bin/tick-shortcuts")
DEFAULT_DESKTOP_DIR = os.path.expanduser("~/.local/share/applications")
DB_PATH = os.path.expanduser("~/.local/share/tick/games.db")

APP_DIR = Path(__file__).resolve().parent
DEV_ASSETS_DIR = APP_DIR / "tick-assets"
RPM_ASSETS_DIR = Path("/usr/share/tick/assets")


def pick_assets_dir() -> Path:
    if (DEV_ASSETS_DIR / "tick_icon.png").exists():
        return DEV_ASSETS_DIR
    return RPM_ASSETS_DIR


ASSETS_DIR = pick_assets_dir()
ICON_PATH = ASSETS_DIR / "tick_icon.png"


# ---------------------------
# Steam Shortcuts Manager (intégré)
# ---------------------------

class SteamShortcutsManager:
    """Gère l'ajout de raccourcis non-Steam dans Steam"""
    
    def __init__(self):
        self.steam_path = self._find_steam_path()
        self.shortcuts_path = None
        if self.steam_path:
            self.shortcuts_path = self._find_shortcuts_vdf()
    
    def _find_steam_path(self) -> Optional[Path]:
        """Trouve le chemin d'installation de Steam"""
        candidates = [
            Path.home() / ".steam" / "steam",
            Path.home() / ".local" / "share" / "Steam",
            Path.home() / ".var" / "app" / "com.valvesoftware.Steam" / ".local" / "share" / "Steam",
            Path("/usr/share/steam"),
            Path("/usr/local/share/steam"),
        ]
        
        for path in candidates:
            if path.exists() and (path / "steamapps").exists():
                return path
        
        return None
    
    def _find_shortcuts_vdf(self) -> Optional[Path]:
        """Trouve le fichier shortcuts.vdf"""
        if not self.steam_path:
            return None
        
        userdata_path = self.steam_path / "userdata"
        if not userdata_path.exists():
            return None
        
        for user_dir in userdata_path.iterdir():
            if user_dir.is_dir() and user_dir.name.isdigit():
                shortcuts_file = user_dir / "config" / "shortcuts.vdf"
                if shortcuts_file.exists():
                    return shortcuts_file
                shortcuts_file.parent.mkdir(parents=True, exist_ok=True)
                return shortcuts_file
        
        return None
    
    def _read_vdf(self, filepath: Path) -> Dict:
        """Lit un fichier VDF binaire et extrait les raccourcis"""
        if not filepath.exists():
            return {"shortcuts": {}}
        
        try:
            import vdf
            with open(filepath, 'rb') as f:
                data = vdf.binary_load(f)
            return data if data else {"shortcuts": {}}
        except ImportError:
            # Fallback sur parser custom si vdf pas installé
            return self._read_vdf_custom(filepath)
        except Exception as e:
            print(f"Erreur lecture VDF (vdf lib): {e}, tentative parser custom")
            return self._read_vdf_custom(filepath)
    
    def _read_vdf_custom(self, filepath: Path) -> Dict:
        """Parser VDF custom (fallback)"""
        if not filepath.exists():
            return {"shortcuts": {}}
        
        try:
            with open(filepath, 'rb') as f:
                data = f.read()
            
            shortcuts = {}
            pos = 0
            
            # Skip header
            if data[0:1] == b'\x00':
                pos = 1
            
            if data[pos:pos+10] == b'\x00shortcuts\x00':
                pos += 11
            
            while pos < len(data):
                if data[pos:pos+2] == b'\x08\x08':
                    break
                
                if data[pos:pos+1] == b'\x00':
                    pos += 1
                    idx_str = ""
                    while pos < len(data) and data[pos:pos+1] != b'\x00':
                        idx_str += chr(data[pos])
                        pos += 1
                    pos += 1
                    
                    if not idx_str:
                        break
                    
                    shortcut = {}
                    
                    while pos < len(data):
                        type_byte = data[pos:pos+1]
                        pos += 1
                        
                        if type_byte == b'\x08':
                            break
                        
                        key = ""
                        while pos < len(data) and data[pos:pos+1] != b'\x00':
                            key += chr(data[pos])
                            pos += 1
                        pos += 1
                        
                        if type_byte == b'\x01':
                            value = ""
                            while pos < len(data) and data[pos:pos+1] != b'\x00':
                                value += chr(data[pos])
                                pos += 1
                            pos += 1
                            shortcut[key] = value
                        elif type_byte == b'\x02':
                            if pos + 4 <= len(data):
                                value = struct.unpack('<I', data[pos:pos+4])[0]
                                pos += 4
                                shortcut[key] = value
                    
                    shortcuts[int(idx_str)] = shortcut
                else:
                    pos += 1
            
            return {"shortcuts": shortcuts}
        
        except Exception as e:
            print(f"Erreur lecture VDF custom: {e}")
            return {"shortcuts": {}}
    
    def _write_vdf(self, filepath: Path, data: Dict):
        """Écrit un fichier VDF binaire"""
        # Backup
        if filepath.exists():
            backup = filepath.with_suffix('.vdf.backup')
            shutil.copy2(filepath, backup)
        
        try:
            import vdf
            with open(filepath, 'wb') as f:
                vdf.binary_dump(data, f)
            print(f"[Steam] VDF écrit avec bibliothèque vdf")
        except ImportError:
            # Fallback sur writer custom
            self._write_vdf_custom(filepath, data)
        except Exception as e:
            print(f"Erreur écriture VDF (vdf lib): {e}, tentative writer custom")
            self._write_vdf_custom(filepath, data)
    
    def _write_vdf_custom(self, filepath: Path, data: Dict):
        """Writer VDF custom (fallback)"""
        with open(filepath, 'wb') as f:
            f.write(b'\x00shortcuts\x00')
            
            shortcuts = data.get("shortcuts", {})
            
            # Trier les indices pour garantir l'ordre
            sorted_indices = sorted(shortcuts.keys())
            
            for idx in sorted_indices:
                shortcut = shortcuts[idx]
                
                f.write(b'\x00')
                f.write(str(idx).encode('utf-8'))
                f.write(b'\x00')
                
                # Écrire les champs dans un ordre spécifique pour compatibilité Steam
                fields_order = ['appid', 'AppName', 'Exe', 'StartDir', 'icon', 'ShortcutPath', 
                               'LaunchOptions', 'IsHidden', 'AllowDesktopConfig', 'AllowOverlay',
                               'OpenVR', 'Devkit', 'DevkitGameID', 'DevkitOverrideAppID', 'LastPlayTime']
                
                # Écrire les champs ordonnés d'abord
                for key in fields_order:
                    if key in shortcut:
                        value = shortcut[key]
                        if isinstance(value, str):
                            f.write(b'\x01')
                            f.write(key.encode('utf-8'))
                            f.write(b'\x00')
                            f.write(value.encode('utf-8'))
                            f.write(b'\x00')
                        elif isinstance(value, int):
                            f.write(b'\x02')
                            f.write(key.encode('utf-8'))
                            f.write(b'\x00')
                            f.write(struct.pack('<I', value))
                
                # Écrire les tags et autres champs restants
                for key, value in shortcut.items():
                    if key not in fields_order:
                        if isinstance(value, str):
                            f.write(b'\x01')
                            f.write(key.encode('utf-8'))
                            f.write(b'\x00')
                            f.write(value.encode('utf-8'))
                            f.write(b'\x00')
                        elif isinstance(value, int):
                            f.write(b'\x02')
                            f.write(key.encode('utf-8'))
                            f.write(b'\x00')
                            f.write(struct.pack('<I', value))
                
                f.write(b'\x08')
            
            f.write(b'\x08')
            f.write(b'\x08')
        
        print(f"[Steam] VDF écrit avec writer custom")
    
    def add_shortcut(self, name: str, exe_path: str, start_dir: str = "",
                     icon_path: str = "", launch_options: str = "",
                     allow_desktop_config: bool = True,
                     allow_overlay: bool = True,
                     is_hidden: bool = False,
                     open_vr: bool = False,
                     devkit: bool = False,
                     tags: List[str] = None) -> bool:
        """Ajoute un raccourci non-Steam"""
        if not self.shortcuts_path:
            return False
        
        # IMPORTANT : Utiliser UNIQUEMENT la bibliothèque vdf
        try:
            import vdf
        except ImportError:
            print("[Steam] ERREUR : bibliothèque vdf requise !")
            print("[Steam] Installez : pip install --break-system-packages vdf")
            return False
        
        # Lire avec vdf
        if self.shortcuts_path.exists():
            with open(self.shortcuts_path, 'rb') as f:
                data = vdf.binary_load(f)
        else:
            data = {"shortcuts": {}}
        
        shortcuts = data.get("shortcuts", {})
        
        # Calculer le prochain index
        if shortcuts:
            # Les clés peuvent être int ou str selon la source
            # Convertir en int pour calculer, puis en str pour vdf
            try:
                indices = [int(k) for k in shortcuts.keys()]
                next_idx = max(indices) + 1
            except (ValueError, TypeError) as e:
                print(f"[Steam] Warning: problème avec les indices ({e}), utilise len()")
                next_idx = len(shortcuts)
        else:
            next_idx = 0
        
        app_id = self._generate_app_id(exe_path, name)
        
        new_shortcut = {
            "appid": app_id,
            "AppName": name,
            "Exe": f'"{exe_path}"',
            "StartDir": f'"{start_dir}"' if start_dir else f'"{os.path.dirname(exe_path)}"',
            "icon": icon_path,
            "ShortcutPath": "",
            "LaunchOptions": launch_options,
            "IsHidden": 1 if is_hidden else 0,
            "AllowDesktopConfig": 1 if allow_desktop_config else 0,
            "AllowOverlay": 1 if allow_overlay else 0,
            "OpenVR": 1 if open_vr else 0,
            "Devkit": 1 if devkit else 0,
            "DevkitGameID": "",
            "DevkitOverrideAppID": 0,
            "LastPlayTime": 0,
        }
        
        if tags:
            for i, tag in enumerate(tags):
                new_shortcut[f"tags.{i}"] = tag
        
        # IMPORTANT : vdf veut des clés STRING
        shortcuts[str(next_idx)] = new_shortcut
        data["shortcuts"] = shortcuts
        
        # Backup
        if self.shortcuts_path.exists():
            backup = self.shortcuts_path.with_suffix('.vdf.backup')
            shutil.copy2(self.shortcuts_path, backup)
        
        # Écrire avec vdf
        try:
            with open(self.shortcuts_path, 'wb') as f:
                vdf.binary_dump(data, f)
            
            print(f"[Steam] ✓ Raccourci ajouté: {name}")
            print(f"[Steam]   Index: {next_idx}")
            print(f"[Steam]   Total jeux: {len(shortcuts)}")
            return True
        
        except Exception as e:
            print(f"[Steam] Erreur écriture VDF: {e}")
            
            # Restaurer backup
            if backup.exists():
                shutil.copy2(backup, self.shortcuts_path)
                print(f"[Steam] Backup restauré")
            
            return False
    
    def _generate_app_id(self, exe_path: str, game_name: str) -> int:
        """Génère un AppID comme Steam le fait (formule officielle)"""
        # Steam utilise : CRC32(exe_path + game_name) avec top bit = 1
        # Mais en UNSIGNED 32-bit, puis converti en signed pour VDF
        
        key = f'"{exe_path}"{game_name}'
        crc = zlib.crc32(key.encode('utf-8')) & 0xFFFFFFFF
        
        # Ajouter le marqueur non-Steam (top bit)
        app_id = crc | 0x80000000
        
        # Convertir en signed int32 pour Python/VDF
        # Si > 2^31-1, soustraire 2^32 pour obtenir la valeur signée
        if app_id > 0x7FFFFFFF:
            app_id = app_id - 0x100000000
        
        return app_id
    
    def shortcut_exists(self, name: str) -> bool:
        """Vérifie si un raccourci existe déjà"""
        if not self.shortcuts_path or not self.shortcuts_path.exists():
            return False
        
        data = self._read_vdf(self.shortcuts_path)
        shortcuts = data["shortcuts"]
        
        for shortcut in shortcuts.values():
            if shortcut.get("AppName") == name:
                return True
        
        return False
    
    def get_all_shortcuts(self) -> List[Dict]:
        """Récupère tous les raccourcis non-Steam"""
        if not self.shortcuts_path or not self.shortcuts_path.exists():
            return []
        
        data = self._read_vdf(self.shortcuts_path)
        return list(data["shortcuts"].values())
    
    def remove_shortcut(self, game_name: str) -> bool:
        """
        Supprime un raccourci de Steam par son nom
        
        Args:
            game_name: Nom du jeu à supprimer
            
        Returns:
            True si le raccourci a été supprimé, False sinon
        """
        if not self.shortcuts_path:
            print("[Steam] Impossible de trouver shortcuts.vdf")
            return False
        
        try:
            # Lire le VDF actuel
            data = self._read_vdf(self.shortcuts_path)
            shortcuts = data.get("shortcuts", {})
            
            if not shortcuts:
                print(f"[Steam] Aucun raccourci trouvé")
                return False
            
            # Chercher le raccourci par nom
            found_index = None
            for idx, shortcut in shortcuts.items():
                if shortcut.get('AppName', '') == game_name or shortcut.get('appname', '') == game_name:
                    found_index = idx
                    break
            
            if found_index is None:
                print(f"[Steam] Raccourci '{game_name}' non trouvé")
                return False
            
            # Supprimer le raccourci
            del shortcuts[found_index]
            
            # Réindexer les raccourcis (0, 1, 2, ...)
            reindexed_shortcuts = {}
            for new_idx, (old_idx, shortcut) in enumerate(sorted(shortcuts.items())):
                reindexed_shortcuts[new_idx] = shortcut
            
            # Sauvegarder
            data["shortcuts"] = reindexed_shortcuts
            self._write_vdf(self.shortcuts_path, data)
            
            print(f"[Steam] ✓ Raccourci '{game_name}' supprimé de Steam")
            return True
        
        except Exception as e:
            print(f"[Steam] Erreur lors de la suppression: {e}")
            return False
    
    def is_shortcut_in_steam(self, game_name: str) -> bool:
        """
        Vérifie si un raccourci existe vraiment dans Steam
        
        Args:
            game_name: Nom du jeu à vérifier
            
        Returns:
            True si le raccourci existe dans shortcuts.vdf, False sinon
        """
        if not self.shortcuts_path or not self.shortcuts_path.exists():
            return False
        
        try:
            data = self._read_vdf(self.shortcuts_path)
            shortcuts = data.get("shortcuts", {})
            
            for shortcut in shortcuts.values():
                app_name = shortcut.get('AppName', '') or shortcut.get('appname', '')
                if app_name == game_name:
                    return True
            
            return False
        
        except Exception as e:
            print(f"[Steam] Erreur vérification raccourci: {e}")
            return False
    
    def is_steam_running(self) -> bool:
        """Vérifie si Steam est en cours d'exécution"""
        try:
            result = subprocess.run(['pgrep', '-x', 'steam'], 
                                  capture_output=True, text=True)
            return result.returncode == 0
        except:
            return False
    
    def is_available(self) -> bool:
        """Vérifie si Steam est disponible"""
        return self.steam_path is not None and self.shortcuts_path is not None


# ---------------------------
# Icon Extractor (intégré)
# ---------------------------

class IconExtractor:
    """Extrait les icônes des fichiers .exe Windows"""
    
    def __init__(self, cache_dir: str = None):
        if cache_dir is None:
            cache_dir = os.path.expanduser("~/.local/share/tick/icons")
        
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        self.wrestool_available = shutil.which("wrestool") is not None
        self.icotool_available = shutil.which("icotool") is not None
        self.convert_available = shutil.which("convert") is not None
    
    def is_available(self) -> bool:
        """Vérifie si les outils sont disponibles"""
        return self.wrestool_available and self.icotool_available
    
    def get_cache_path(self, exe_path: str, size: int = 256) -> Path:
        """Génère le chemin de cache pour une icône"""
        import hashlib
        hash_name = hashlib.md5(exe_path.encode()).hexdigest()
        filename = f"{hash_name}_{size}.png"
        return self.cache_dir / filename
    
    def extract_icon(self, exe_path: str, output_path: str = None, 
                     size: int = 256, use_cache: bool = True) -> Optional[str]:
        """Extrait l'icône d'un fichier .exe"""
        if not os.path.exists(exe_path):
            return None
        
        if output_path is None:
            output_path = str(self.get_cache_path(exe_path, size))
        
        if use_cache and os.path.exists(output_path):
            return output_path
        
        if self.wrestool_available and self.icotool_available:
            result = self._extract_with_icotools(exe_path, output_path, size)
            if result:
                return result
        
        return None
    
    def _extract_with_icotools(self, exe_path: str, output_path: str, 
                               size: int = 256) -> Optional[str]:
        """Extrait l'icône avec wrestool + icotool"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)
            ico_file = tmpdir_path / "icon.ico"
            
            try:
                result = subprocess.run(
                    ["wrestool", "-x", "--output", str(ico_file), "-t", "14", exe_path],
                    capture_output=True,
                    timeout=10
                )
                
                if result.returncode != 0 or not ico_file.exists():
                    return None
                
                result = subprocess.run(
                    ["icotool", "-x", str(ico_file), "-o", str(tmpdir_path)],
                    capture_output=True,
                    timeout=10
                )
                
                if result.returncode != 0:
                    return None
                
                png_files = list(tmpdir_path.glob("*.png"))
                if not png_files:
                    return None
                
                best_png = max(png_files, key=lambda f: f.stat().st_size)
                
                if self.convert_available:
                    subprocess.run(
                        ["convert", str(best_png), "-resize", f"{size}x{size}", output_path],
                        capture_output=True,
                        timeout=10
                    )
                else:
                    shutil.copy2(best_png, output_path)
                
                if os.path.exists(output_path):
                    return output_path
            
            except subprocess.TimeoutExpired:
                pass
            except Exception as e:
                print(f"Erreur extraction: {e}")
        
        return None
    
    def clear_cache(self):
        """Supprime toutes les icônes en cache"""
        if self.cache_dir.exists():
            shutil.rmtree(self.cache_dir)
            self.cache_dir.mkdir(parents=True, exist_ok=True)


def install_dependencies_instructions() -> str:
    """Instructions pour installer les dépendances"""
    return """
Pour extraire les icônes des fichiers .exe, installez :

Ubuntu/Debian:
    sudo apt install icoutils imagemagick

Fedora:
    sudo dnf install icoutils ImageMagick

Arch:
    sudo pacman -S icoutils imagemagick
"""


# ---------------------------
# Game Info Extractor
# ---------------------------

class GameInfoExtractor:
    """Extrait les informations d'un jeu (nom, éditeur, version) depuis un .exe"""
    
    def __init__(self):
        self.peres_available = shutil.which("wrestool") is not None
    
    def extract_game_name(self, exe_path: str) -> str:
        """
        Extrait le nom du jeu depuis plusieurs sources
        
        Priorité:
        1. Métadonnées du .exe (ProductName)
        2. Nom du dossier parent principal
        3. Nom du .exe nettoyé
        """
        if not os.path.exists(exe_path):
            return Path(exe_path).stem
        
        # Méthode 1: Métadonnées du .exe
        metadata_name = self._extract_from_exe_metadata(exe_path)
        if metadata_name:
            return metadata_name
        
        # Méthode 2: Nom du dossier parent
        folder_name = self._extract_from_folder(exe_path)
        if folder_name:
            return folder_name
        
        # Méthode 3: Nom du fichier .exe nettoyé
        return self._clean_exe_name(Path(exe_path).stem)
    
    def _extract_from_exe_metadata(self, exe_path: str) -> Optional[str]:
        """Extrait le ProductName des métadonnées du .exe"""
        try:
            # Méthode 1: wrestool (même outil que pour les icônes)
            if self.peres_available:
                result = subprocess.run(
                    ["wrestool", "-x", "-t", "16", exe_path],
                    capture_output=True,
                    timeout=5,
                    text=False
                )
                
                if result.returncode == 0 and result.stdout:
                    # Chercher ProductName dans les ressources
                    output = result.stdout
                    
                    # Les métadonnées sont en UTF-16LE
                    try:
                        # Chercher les patterns communs
                        patterns = [
                            b'ProductName\x00\x00',
                            b'F\x00i\x00l\x00e\x00D\x00e\x00s\x00c\x00r\x00i\x00p\x00t\x00i\x00o\x00n\x00',
                        ]
                        
                        for pattern in patterns:
                            idx = output.find(pattern)
                            if idx != -1:
                                # Avancer après le pattern
                                start = idx + len(pattern)
                                # Lire jusqu'au prochain null ou max 200 bytes
                                end = start
                                name_bytes = bytearray()
                                
                                while end < len(output) and end - start < 200:
                                    byte = output[end]
                                    if byte == 0 and len(name_bytes) > 0:
                                        # Double null = fin
                                        if end + 1 < len(output) and output[end + 1] == 0:
                                            break
                                    name_bytes.append(byte)
                                    end += 1
                                
                                try:
                                    # Décoder UTF-16LE
                                    name = bytes(name_bytes).decode('utf-16le', errors='ignore').strip('\x00')
                                    if name and len(name) > 2 and len(name) < 100:
                                        # Nettoyer
                                        name = name.strip()
                                        # Enlever les caractères de contrôle
                                        name = ''.join(c for c in name if c.isprintable())
                                        if name:
                                            print(f"[GameInfo] Nom depuis métadonnées: {name}")
                                            return name
                                except:
                                    pass
                    except Exception as e:
                        print(f"[GameInfo] Erreur parsing métadonnées: {e}")
        
        except subprocess.TimeoutExpired:
            pass
        except Exception as e:
            print(f"[GameInfo] Erreur extraction métadonnées: {e}")
        
        return None
    
    def _extract_from_folder(self, exe_path: str) -> Optional[str]:
        """
        Extrait le nom depuis le dossier parent
        
        Ex: C:/Program Files/Cyberpunk 2077/bin/x64/game.exe
        → "Cyberpunk 2077"
        """
        path = Path(exe_path)
        parts = path.parts
        
        # Ignorer ces dossiers communs
        ignore_folders = {
            'bin', 'x64', 'x86', 'win64', 'win32', 'binaries',
            'game', 'exe', 'system', 'data', 'files'
        }
        
        # Ignorer Program Files
        ignore_prefixes = {
            'program files', 'program files (x86)', 'programfiles'
        }
        
        # Parcourir du parent vers la racine
        for i in range(len(parts) - 2, -1, -1):
            folder = parts[i]
            folder_lower = folder.lower()
            
            # Skip drive_c et chemins système
            if folder_lower in ['drive_c', 'windows', 'system32']:
                continue
            
            # Skip dossiers techniques
            if folder_lower in ignore_folders:
                continue
            
            # Skip Program Files
            if any(folder_lower.startswith(prefix) for prefix in ignore_prefixes):
                continue
            
            # C'est probablement le dossier du jeu !
            cleaned = self._clean_folder_name(folder)
            if cleaned and len(cleaned) > 2:
                print(f"[GameInfo] Nom depuis dossier: {cleaned}")
                return cleaned
        
        return None
    
    def _clean_folder_name(self, folder_name: str) -> str:
        """Nettoie un nom de dossier"""
        # Enlever les underscores/tirets
        name = folder_name.replace('_', ' ').replace('-', ' ')
        
        # Enlever les versions/numéros entre parenthèses
        name = re.sub(r'\([^)]*\)', '', name)
        
        # Enlever les versions style "v1.0"
        name = re.sub(r'\bv?\d+\.\d+.*$', '', name, flags=re.IGNORECASE)
        
        # Nettoyer les espaces multiples
        name = re.sub(r'\s+', ' ', name).strip()
        
        return name
    
    def _clean_exe_name(self, exe_name: str) -> str:
        """
        Nettoie le nom d'un .exe pour en faire un nom de jeu présentable
        
        Ex: "Cyberpunk2077" → "Cyberpunk 2077"
        """
        name = exe_name
        
        # Enlever les suffixes communs
        suffixes = [
            'game', 'launcher', 'x64', 'x86', 'win64', 'win32',
            'dx11', 'dx12', 'vulkan', 'shipping', 'final'
        ]
        
        for suffix in suffixes:
            # Case insensitive
            pattern = re.compile(re.escape(suffix) + r'$', re.IGNORECASE)
            name = pattern.sub('', name)
        
        # Enlever underscores et tirets
        name = name.replace('_', ' ').replace('-', ' ')
        
        # Ajouter des espaces avant les majuscules (CamelCase)
        # "Cyberpunk2077" → "Cyberpunk 2077"
        name = re.sub(r'([a-z])([A-Z])', r'\1 \2', name)
        name = re.sub(r'([a-zA-Z])(\d)', r'\1 \2', name)
        name = re.sub(r'(\d)([a-zA-Z])', r'\1 \2', name)
        
        # Nettoyer les espaces multiples
        name = re.sub(r'\s+', ' ', name).strip()
        
        # Capitaliser correctement
        # "cyberpunk 2077" → "Cyberpunk 2077"
        words = name.split()
        name = ' '.join(word.capitalize() if len(word) > 2 else word for word in words)
        
        return name
    
    def extract_full_info(self, exe_path: str) -> Dict[str, str]:
        """
        Extrait toutes les infos disponibles
        
        Returns:
            {
                'name': str,
                'folder': str,
                'exe_name': str,
                'version': str,
                'publisher': str
            }
        """
        info = {
            'name': self.extract_game_name(exe_path),
            'folder': self._extract_from_folder(exe_path) or '',
            'exe_name': self._clean_exe_name(Path(exe_path).stem),
            'version': '',
            'publisher': ''
        }
        
        return info


# ---------------------------
# Database Management
# ---------------------------

class GameDatabase:
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        ensure_dir(str(Path(db_path).parent))
        self._init_db()
    
    def _init_db(self):
        """Initialise la base de données"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS games (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                bottle_name TEXT NOT NULL,
                exe_path TEXT NOT NULL,
                win_path TEXT NOT NULL,
                shortcut_path TEXT,
                desktop_path TEXT,
                icon_path TEXT,
                steam_added INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_played TIMESTAMP,
                play_count INTEGER DEFAULT 0,
                UNIQUE(name, bottle_name)
            )
        """)
        
        # Migration: ajouter les colonnes manquantes
        for column_def in [
            ("steam_added", "INTEGER DEFAULT 0"),
            ("icon_path", "TEXT"),
        ]:
            try:
                cursor.execute(f"ALTER TABLE games ADD COLUMN {column_def[0]} {column_def[1]}")
                conn.commit()
            except sqlite3.OperationalError:
                # La colonne existe déjà
                pass
        
        conn.commit()
        conn.close()
    
    def add_game(self, name: str, bottle_name: str, exe_path: str, 
                 win_path: str, shortcut_path: str = None, 
                 desktop_path: str = None, icon_path: str = None) -> int:
        """Ajoute un jeu à la base de données"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT INTO games (name, bottle_name, exe_path, win_path, shortcut_path, desktop_path, icon_path)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (name, bottle_name, exe_path, win_path, shortcut_path, desktop_path, icon_path))
            
            game_id = cursor.lastrowid
            conn.commit()
            return game_id
        except sqlite3.IntegrityError:
            # Le jeu existe déjà, on le met à jour
            cursor.execute("""
                UPDATE games 
                SET exe_path = ?, win_path = ?, shortcut_path = ?, 
                    desktop_path = ?, icon_path = ?, updated_at = CURRENT_TIMESTAMP
                WHERE name = ? AND bottle_name = ?
            """, (exe_path, win_path, shortcut_path, desktop_path, icon_path, name, bottle_name))
            
            cursor.execute("""
                SELECT id FROM games WHERE name = ? AND bottle_name = ?
            """, (name, bottle_name))
            
            game_id = cursor.fetchone()[0]
            conn.commit()
            return game_id
        finally:
            conn.close()
    
    def update_play_stats(self, game_id: int):
        """Met à jour les statistiques de jeu"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            UPDATE games 
            SET last_played = CURRENT_TIMESTAMP,
                play_count = play_count + 1
            WHERE id = ?
        """, (game_id,))
        
        conn.commit()
        conn.close()
    
    def get_all_games(self) -> list[dict]:
        """Récupère tous les jeux"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT * FROM games ORDER BY last_played DESC, name ASC
        """)
        
        games = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return games
    
    def get_game_by_id(self, game_id: int) -> Optional[dict]:
        """Récupère un jeu par son ID"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM games WHERE id = ?", (game_id,))
        row = cursor.fetchone()
        
        conn.close()
        return dict(row) if row else None
    
    def delete_game(self, game_id: int) -> bool:
        """Supprime un jeu de la base de données"""
        game = self.get_game_by_id(game_id)
        if not game:
            return False
        
        # Supprimer les fichiers associés
        if game['shortcut_path'] and os.path.exists(game['shortcut_path']):
            try:
                os.remove(game['shortcut_path'])
            except Exception:
                pass
        
        if game['desktop_path'] and os.path.exists(game['desktop_path']):
            try:
                os.remove(game['desktop_path'])
            except Exception:
                pass
        
        # Supprimer de la DB
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM games WHERE id = ?", (game_id,))
        conn.commit()
        conn.close()
        
        return True
    
    def mark_as_added_to_steam(self, game_id: int, added: bool = True):
        """Marque un jeu comme ajouté à Steam"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE games SET steam_added = ? WHERE id = ?
        """, (1 if added else 0, game_id))
        conn.commit()
        conn.close()


# ---------------------------
# .desktop File Generation
# ---------------------------

def create_desktop_file(name: str, shortcut_path: str, bottle_name: str,
                       exe_path: str, desktop_dir: str = DEFAULT_DESKTOP_DIR,
                       icon_path: str = None) -> str:
    """
    Crée un fichier .desktop pour le jeu
    
    Args:
        name: Nom du jeu
        shortcut_path: Chemin vers le script shell
        bottle_name: Nom de la bouteille Bottles
        exe_path: Chemin Linux vers l'exe
        desktop_dir: Dossier où créer le .desktop
        icon_path: Chemin vers l'icône (icône extraite du jeu ou icône TICK)
    
    Returns:
        Chemin du fichier .desktop créé
    """
    ensure_dir(desktop_dir)
    
    slug = slugify(name)
    desktop_file = os.path.join(desktop_dir, f"tick-{slug}.desktop")
    
    # Priorité: icône extraite > icône TICK > icône système
    if not icon_path or not os.path.exists(icon_path):
        if ICON_PATH.exists():
            icon_path = str(ICON_PATH)
        else:
            icon_path = 'applications-games'
    
    content = f"""[Desktop Entry]
Version=1.0
Type=Application
Name={name}
Comment=Lancé via T.I.C.K ({bottle_name})
Exec={shortcut_path}
Icon={icon_path}
Terminal=false
Categories=Game;
Keywords=game;wine;bottles;windows;
StartupNotify=true
"""
    
    Path(desktop_file).write_text(content, encoding="utf-8")
    os.chmod(desktop_file, 0o755)
    
    return desktop_file


# ---------------------------
# Safety
# ---------------------------

EXE_BLACKLIST = {
    "upc.exe", "uplaywebcore.exe", "uplayservice.exe",
    "eadesktop.exe", "ealauncher.exe",
    "unins000.exe", "uninstall.exe", "setup.exe", "installer.exe",
}


def which(cmd: str) -> str | None:
    return shutil.which(cmd)


def bottles_cli_exists() -> bool:
    return which("bottles-cli") is not None


def run_cmd(args: list[str]) -> tuple[int, str]:
    try:
        out = subprocess.check_output(args, stderr=subprocess.STDOUT, text=True)
        return 0, out
    except subprocess.CalledProcessError as e:
        return e.returncode, e.output
    except Exception as e:
        return 1, str(e)


def list_bottles() -> list[str]:
    code, out = run_cmd(["bottles-cli", "list", "bottles"])
    if code != 0:
        return []
    bottles: list[str] = []
    for line in out.splitlines():
        line = line.strip()
        if line.startswith("- "):
            bottles.append(line[2:].strip())
    return bottles


def slugify(name: str) -> str:
    s = name.strip().lower()
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = re.sub(r"(^-+)|(-+$)", "", s)
    return s or "game"


def linux_exe_to_windows_path(linux_path: str) -> str:
    marker = "/drive_c/"
    if marker not in linux_path:
        raise ValueError("Le chemin doit contenir '/drive_c/' pour être converti en C:\\...")
    tail = linux_path.split(marker, 1)[1]
    return "C:\\" + tail.replace("/", "\\")


def ensure_dir(path: str) -> None:
    Path(path).mkdir(parents=True, exist_ok=True)


def write_executable(path: str, content: str) -> None:
    p = Path(path)
    p.write_text(content, encoding="utf-8")
    mode = p.stat().st_mode
    p.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def html_escape(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


# ---------------------------
# Header: generated from icon (no banner file)
# ---------------------------

def make_header_pixmap(width: int = 520, height: int = 100) -> QPixmap:
    """
    Génère un header propre 520x100 à partir de tick_icon.png.
    Pas de bannière externe => pas de ratio qui casse.
    """
    pm = QPixmap(width, height)
    pm.fill(Qt.transparent)

    painter = QPainter(pm)
    painter.setRenderHints(
        QPainter.Antialiasing
        | QPainter.TextAntialiasing
        | QPainter.SmoothPixmapTransform
    )

    # Icon
    icon_size = 84
    icon_margin_left = 10
    icon_margin_top = (height - icon_size) // 2

    icon_pm = QPixmap(str(ICON_PATH)) if ICON_PATH.exists() else QPixmap()
    if not icon_pm.isNull():
        icon_scaled = icon_pm.scaled(icon_size, icon_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        ix = icon_margin_left + (icon_size - icon_scaled.width()) // 2
        iy = icon_margin_top + (icon_size - icon_scaled.height()) // 2
        painter.drawPixmap(ix, iy, icon_scaled)
    else:
        # fallback simple
        painter.setPen(QColor(120, 120, 120))
        painter.drawRect(QRect(icon_margin_left, icon_margin_top, icon_size, icon_size))

    # Text block (simple, clean)
    text_x = icon_margin_left + icon_size + 14
    text_w = width - text_x - 10

    title_font = QFont()
    title_font.setPointSize(18)
    title_font.setBold(True)

    sub_font = QFont()
    sub_font.setPointSize(10)
    sub_font.setBold(False)

    painter.setPen(QColor(20, 20, 20))

    painter.setFont(title_font)
    painter.drawText(QRect(text_x, 18, text_w, 28), Qt.AlignLeft | Qt.AlignVCenter, "T.I.C.K")

    painter.setFont(sub_font)
    painter.setPen(QColor(70, 70, 70))
    painter.drawText(
        QRect(text_x, 46, text_w, 40),
        Qt.AlignLeft | Qt.AlignTop,
        "Target Input Compatible Kickoff"
    )

    painter.end()
    return pm


# ---------------------------
# Bottles: robust locate bottle dir + drive_c
# ---------------------------

def bottles_get_workdir() -> str | None:
    candidates = [
        ["bottles-cli", "config", "get", "working_directory"],
        ["bottles-cli", "config", "get", "working-dir"],
        ["bottles-cli", "config", "get", "workdir"],
        ["bottles-cli", "config", "get", "workingDirectory"],
    ]
    for cmd in candidates:
        code, out = run_cmd(cmd)
        if code == 0:
            val = out.strip().strip('"').strip("'")
            if val:
                val = os.path.expanduser(val)
                if os.path.isdir(val):
                    return val
    return None


def bottles_try_get_bottle_basepath(bottle_name: str) -> str | None:
    bottle_name = bottle_name.strip()
    if not bottle_name:
        return None

    candidates = [
        ["bottles-cli", "info", "-b", bottle_name],
        ["bottles-cli", "bottle", "info", "-b", bottle_name],
        ["bottles-cli", "bottles", "info", "-b", bottle_name],
    ]

    path_re = re.compile(r"(/[^ \n\t]+)")

    for cmd in candidates:
        code, out = run_cmd(cmd)
        if code != 0 or not out.strip():
            continue

        for line in out.splitlines():
            low = line.lower()
            if any(k in low for k in ["path", "directory", "bottle", "prefix"]):
                m = path_re.search(line)
                if m:
                    p = os.path.expanduser(m.group(1))
                    if os.path.isdir(p):
                        return p

        for m in path_re.finditer(out):
            p = os.path.expanduser(m.group(1))
            if os.path.isdir(p):
                return p

    return None


def _read_bottle_name_from_yaml(yaml_path: Path) -> str | None:
    try:
        txt = yaml_path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return None

    for line in txt.splitlines()[:250]:
        s = line.strip()
        if not s:
            continue
        low = s.lower()
        if low.startswith("name:"):
            val = s.split(":", 1)[1].strip().strip('"').strip("'")
            return val or None
        if s.startswith("Name:"):
            val = s.split(":", 1)[1].strip().strip('"').strip("'")
            return val or None
    return None


def find_bottle_dir_by_metadata(bottle_name: str, roots: list[str]) -> str | None:
    """Cherche une bouteille en lisant les fichiers bottle.yml"""
    target = bottle_name.strip().lower()
    if not target:
        return None

    for root in roots:
        root = os.path.expanduser(root)
        if not os.path.isdir(root):
            continue

        try:
            for child in Path(root).iterdir():
                if not child.is_dir():
                    continue

                yml1 = child / "bottle.yml"
                yml2 = child / "bottle.yaml"
                yaml_file = yml1 if yml1.exists() else (yml2 if yml2.exists() else None)
                if not yaml_file:
                    continue

                name = _read_bottle_name_from_yaml(yaml_file)
                if name and name.strip().lower() == target:
                    return str(child)
        except Exception:
            continue

    return None


def _norm_key(s: str) -> str:
    """Normalise un nom pour la comparaison (enlève espaces, tirets, etc)"""
    s = s.strip().lower()
    s = re.sub(r"[\s_\-]+", "", s)
    s = re.sub(r"[^a-z0-9]", "", s)
    return s


def _name_variants(name: str) -> list[str]:
    """Génère des variantes d'un nom (avec/sans espaces, tirets, underscores)"""
    name = name.strip()
    if not name:
        return []
    v = {name}
    v.add(name.replace(" ", "-"))
    v.add(name.replace(" ", "_"))
    v.add(name.replace("-", " "))
    v.add(name.replace("_", " "))
    v.add(name.replace("-", "_"))
    v.add(name.replace("_", "-"))
    v.add(name.replace(" ", ""))
    return [x for x in v if x]


def guess_bottle_drive_c(bottle_name: str) -> str | None:
    """
    Trouve le drive_c d'une bouteille Bottles de manière robuste.
    Utilise plusieurs méthodes de recherche.
    """
    bottle_name = bottle_name.strip()
    if not bottle_name:
        return None

    # Méthode 1: Via bottles-cli info
    base = bottles_try_get_bottle_basepath(bottle_name)
    if base:
        for candidate in [
            os.path.join(base, "drive_c"),
            os.path.join(base, "prefix", "drive_c"),
        ]:
            if os.path.isdir(candidate):
                return candidate

    # Construire la liste des racines à explorer
    workdir = bottles_get_workdir()
    roots: list[str] = []
    
    if workdir:
        roots.extend([
            workdir,
            os.path.join(workdir, "Bottles"),
            os.path.join(workdir, "bottles"),
            os.path.join(workdir, "Games"),
            os.path.join(workdir, "games"),
        ])

    # Ajouter les emplacements standards
    home = str(Path.home())
    roots.extend([
        os.path.join(home, ".local", "share", "bottles", "bottles"),
        os.path.join(home, "Games"),
        os.path.join(home, ".var", "app", "com.usebottles.bottles", "data", "bottles", "bottles"),
    ])

    # Méthode 2: Lecture des métadonnées (bottle.yml)
    base2 = find_bottle_dir_by_metadata(bottle_name, roots)
    if base2:
        for candidate in [
            os.path.join(base2, "drive_c"),
            os.path.join(base2, "prefix", "drive_c"),
        ]:
            if os.path.isdir(candidate):
                return candidate

    # Méthode 3: Test des variantes de noms
    variants = _name_variants(bottle_name)
    for root in roots:
        root = os.path.expanduser(root)
        for bn in variants:
            for candidate in [
                os.path.join(root, bn, "drive_c"),
                os.path.join(root, bn, "prefix", "drive_c"),
            ]:
                if os.path.isdir(candidate):
                    return candidate

    # Méthode 4: Normalisation poussée + scan des dossiers
    target_key = _norm_key(bottle_name)
    for root in roots:
        rootp = Path(os.path.expanduser(root))
        if not rootp.is_dir():
            continue
        try:
            for child in rootp.iterdir():
                if not child.is_dir():
                    continue
                if _norm_key(child.name) != target_key:
                    continue
                for candidate in [child / "drive_c", child / "prefix" / "drive_c"]:
                    if candidate.is_dir():
                        return str(candidate)
        except Exception:
            continue

    return None


def _is_probably_noise_exe(path: Path) -> bool:
    """Détecte les exe de bruit (installeurs, désinstalleurs, etc)"""
    name = path.name.lower()
    if name in EXE_BLACKLIST:
        return True
    if name.startswith("unins") or "uninstall" in name or "installer" in name or "setup" in name:
        return True
    return False


def _normalize_query(q: str) -> list[str]:
    """Normalise la requête de recherche en tokens"""
    q = q.strip().lower()
    q = re.sub(r"\s+", " ", q)
    if not q:
        return []
    return [t for t in q.split(" ") if t]


def _matches_query(path: Path, tokens: list[str]) -> bool:
    """Vérifie si un chemin correspond aux tokens de recherche"""
    if not tokens:
        return True
    hay = (str(path).lower() + " " + path.stem.lower())
    return all(t in hay for t in tokens)


def _score_exe_path(p: Path, tokens: list[str]) -> tuple[int, int, int, str]:
    """
    Score un exe pour le tri (plus petit = meilleur)
    Retourne: (pénalité, profondeur, longueur_nom, nom)
    """
    s = str(p).lower()
    penalty = 0
    
    # Pénaliser les dossiers système
    if "/windows/" in s or "\\windows\\" in s:
        penalty += 50
    if "/system32/" in s or "\\system32\\" in s:
        penalty += 50
    
    # Favoriser Program Files
    if "/program files" in s or "\\program files" in s:
        penalty -= 10
    if "/program files (x86)" in s or "\\program files (x86)" in s:
        penalty -= 8

    # Favoriser les correspondances directes dans le nom
    stem = p.stem.lower()
    direct_hits = sum(1 for t in tokens if t in stem)
    penalty -= min(direct_hits, 3) * 5

    depth = len(p.parts)
    name_len = len(p.name)
    return (penalty, depth, name_len, p.name.lower())


def find_exes_in_drive_c(drive_c: str, query: str, stop_event: threading.Event) -> list[str]:
    """
    Cherche des .exe dans un drive_c en fonction d'une requête.
    Retourne une liste triée par pertinence.
    """
    root = Path(drive_c)
    if not root.is_dir():
        return []

    tokens = _normalize_query(query)

    # Dossiers à ignorer
    skip_dirs = {
        "windows", "system32", "syswow64", "winsxs", "temp", "tmp",
        "programdata", "$recycle.bin",
    }

    found: list[Path] = []

    for dirpath, dirnames, filenames in os.walk(root):
        if stop_event.is_set():
            break

        d = Path(dirpath)
        base = d.name.lower()
        if base in skip_dirs:
            dirnames[:] = []
            continue

        # Filtrer les sous-dossiers à ignorer
        dirnames[:] = [dn for dn in dirnames if dn.lower() not in skip_dirs]

        for fn in filenames:
            if stop_event.is_set():
                break
            if not fn.lower().endswith(".exe"):
                continue
            p = d / fn
            if _is_probably_noise_exe(p):
                continue
            if not _matches_query(p, tokens):
                continue
            found.append(p)

    # Trier par score de pertinence
    found.sort(key=lambda p: _score_exe_path(p, tokens))

    # Dédupliquer
    out: list[str] = []
    seen = set()
    for p in found:
        s = str(p)
        if s in seen:
            continue
        seen.add(s)
        out.append(s)
    return out


# ---------------------------
# Game Library Tab
# ---------------------------

class GameLibraryTab(QWidget):
    def __init__(self, db: GameDatabase):
        super().__init__()
        self.db = db
        self.steam_manager = SteamShortcutsManager() if STEAM_SUPPORT else None
        self.config_dir = Path.home() / ".config" / "tick"
        self.config_file = self.config_dir / "config.json"
        self._init_ui()
        self.refresh_games()
    
    def _load_config(self) -> Dict:
        """Charge la configuration depuis le fichier JSON"""
        if not self.config_file.exists():
            return {}
        
        try:
            import json
            with open(self.config_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"[Config] Erreur lecture config: {e}")
            return {}
    
    def _save_config(self, config: Dict):
        """Sauvegarde la configuration dans le fichier JSON"""
        try:
            import json
            self.config_dir.mkdir(parents=True, exist_ok=True)
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
            print(f"[Config] Configuration sauvegardée")
        except Exception as e:
            print(f"[Config] Erreur sauvegarde config: {e}")
    
    def _get_api_key(self) -> Optional[str]:
        """Récupère la clé API (depuis config ou demande à l'user)"""
        # Essayer de charger depuis config
        config = self._load_config()
        api_key = config.get('steamgriddb_api_key')
        
        if api_key:
            return api_key
        
        # Demander à l'utilisateur
        from PySide6.QtWidgets import QInputDialog
        
        api_key, ok = QInputDialog.getText(
            self, "SteamGridDB API Key",
            "Entrez votre clé API SteamGridDB:\n"
            "(Gratuit sur https://www.steamgriddb.com/profile/preferences/api)\n\n"
            "Cette clé sera sauvegardée pour les prochaines fois.",
            QLineEdit.Normal
        )
        
        if ok and api_key:
            api_key = api_key.strip()
            # Sauvegarder dans config
            config['steamgriddb_api_key'] = api_key
            self._save_config(config)
            return api_key
        
        return None
    
    def _init_ui(self):
        layout = QVBoxLayout(self)
        
        # Header
        header_layout = QHBoxLayout()
        header_label = QLabel("<h2>🔗 Raccourcis créés</h2>")
        header_layout.addWidget(header_label)
        
        # Description
        desc_label = QLabel("<i>Liste des raccourcis créés par T.I.C.K</i>")
        desc_label.setStyleSheet("color: #666;")
        header_layout.addWidget(desc_label)
        
        # Steam status
        if STEAM_SUPPORT and self.steam_manager and self.steam_manager.is_available():
            steam_status = QLabel("✓ Steam détecté")
            steam_status.setStyleSheet("color: green;")
        else:
            steam_status = QLabel("✗ Steam non disponible")
            steam_status.setStyleSheet("color: orange;")
        header_layout.addWidget(steam_status)
        header_layout.addStretch()
        
        layout.addLayout(header_layout)
        
        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(5)  # ID, Nom, Bouteille, Steam, .desktop
        self.table.setHorizontalHeaderLabels([
            "ID", "Nom", "Bouteille", "Steam", ".desktop"
        ])
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        layout.addWidget(self.table)
        
        # Message Steam (caché par défaut)
        self.steam_message = QLabel()
        self.steam_message.setText("⚠️ Redémarrez Steam pour voir les changements")
        self.steam_message.setStyleSheet("""
            background: white;
            border: 1px solid #ff9800;
            border-radius: 3px;
            padding: 8px;
            color: #ff9800;
            font-weight: bold;
        """)
        self.steam_message.setVisible(False)
        layout.addWidget(self.steam_message)
        
        # Buttons
        btn_layout = QHBoxLayout()
        
        self.btn_refresh = QPushButton("🔄 Actualiser")
        self.btn_refresh.clicked.connect(self.refresh_games)
        btn_layout.addWidget(self.btn_refresh)
        
        self.btn_regenerate = QPushButton("🔄 Régénérer")
        self.btn_regenerate.clicked.connect(self.regenerate_selected_game)
        self.btn_regenerate.setToolTip("Régénère tous les fichiers du jeu (répare les problèmes)")
        btn_layout.addWidget(self.btn_regenerate)
        
        self.btn_delete = QPushButton("🗑️ Supprimer")
        self.btn_delete.clicked.connect(self.delete_selected_game)
        self.btn_delete.setToolTip("Supprimer le raccourci complètement")
        btn_layout.addWidget(self.btn_delete)
        
        btn_layout.addStretch()
        layout.addLayout(btn_layout)
    
    def refresh_games(self):
        """Rafraîchit la liste des jeux"""
        games = self.db.get_all_games()
        self.table.setRowCount(len(games))
        
        # Définir la hauteur des lignes
        for row in range(len(games)):
            self.table.setRowHeight(row, 48)
        
        for row, game in enumerate(games):
            # ID
            self.table.setItem(row, 0, QTableWidgetItem(str(game['id'])))
            
            # Nom avec icône
            name_item = QTableWidgetItem(game['name'])
            if game.get('icon_path') and os.path.exists(game['icon_path']):
                icon = QIcon(game['icon_path'])
                name_item.setIcon(icon)
            self.table.setItem(row, 1, name_item)
            
            # Bouteille
            self.table.setItem(row, 2, QTableWidgetItem(game['bottle_name']))
            
            # Steam - CheckBox
            steam_widget = QWidget()
            steam_layout = QHBoxLayout(steam_widget)
            steam_layout.setContentsMargins(0, 0, 0, 0)
            steam_layout.setAlignment(Qt.AlignCenter)
            
            steam_check = QCheckBox()
            
            # Vérifier si le jeu est VRAIMENT dans Steam (pas juste la DB)
            if STEAM_SUPPORT and self.steam_manager and self.steam_manager.is_available():
                actually_in_steam = self.steam_manager.is_shortcut_in_steam(game['name'])
                
                # Si désynchronisé, corriger la DB silencieusement
                if bool(game.get('steam_added', 0)) != actually_in_steam:
                    self.db.mark_as_added_to_steam(game['id'], actually_in_steam)
                    print(f"[T.I.C.K] Sync: '{game['name']}' steam_added → {actually_in_steam}")
                
                steam_check.setChecked(actually_in_steam)
            else:
                # Pas de Steam, utiliser la DB
                steam_check.setChecked(bool(game.get('steam_added', 0)))
            
            steam_check.clicked.connect(lambda checked, gid=game['id']: self.toggle_steam(gid, checked))
            steam_layout.addWidget(steam_check)
            
            self.table.setCellWidget(row, 3, steam_widget)
            
            # .desktop - CheckBox
            desktop_widget = QWidget()
            desktop_layout = QHBoxLayout(desktop_widget)
            desktop_layout.setContentsMargins(0, 0, 0, 0)
            desktop_layout.setAlignment(Qt.AlignCenter)
            
            desktop_check = QCheckBox()
            desktop_path = game.get('desktop_path')
            desktop_exists = bool(desktop_path and os.path.exists(desktop_path))
            desktop_check.setChecked(desktop_exists)
            desktop_check.clicked.connect(lambda checked, gid=game['id']: self.toggle_desktop(gid, checked))
            desktop_layout.addWidget(desktop_check)
            
            self.table.setCellWidget(row, 4, desktop_widget)
    
    def toggle_steam(self, game_id: int, checked: bool):
        """Toggle l'état Steam d'un jeu"""
        if not STEAM_SUPPORT or not self.steam_manager:
            return
        
        game = self.db.get_game_by_id(game_id)
        if not game:
            return
        
        try:
            if checked:
                # Ajouter à Steam
                shortcut_path = game['shortcut_path']
                start_dir = str(Path(shortcut_path).parent)
                icon_path = game.get('icon_path', '')
                
                success = self.steam_manager.add_shortcut(
                    name=game['name'],
                    exe_path=shortcut_path,
                    start_dir=start_dir,
                    icon_path=icon_path,
                    launch_options="",
                    allow_desktop_config=True,
                    allow_overlay=True,
                    tags=["T.I.C.K", "Bottles", game['bottle_name']]
                )
                
                if success:
                    self.db.mark_as_added_to_steam(game_id, True)
                    self.steam_message.setVisible(True)
            else:
                # Retirer de Steam
                if self.steam_manager.remove_shortcut(game['name']):
                    self.db.mark_as_added_to_steam(game_id, False)
                    self.steam_message.setVisible(True)
        
        except Exception as e:
            print(f"[Toggle Steam] Erreur: {e}")
    
    def toggle_desktop(self, game_id: int, checked: bool):
        """Toggle l'état .desktop d'un jeu"""
        print(f"[Toggle Desktop] game_id={game_id}, checked={checked}")
        
        game = self.db.get_game_by_id(game_id)
        if not game:
            print(f"[Toggle Desktop] Jeu {game_id} introuvable")
            return
        
        try:
            if checked:
                # Créer .desktop
                desktop_path = game.get('desktop_path')
                if not desktop_path:
                    # Générer le chemin
                    safe_name = game['name'].lower().replace(' ', '-').replace("'", '').replace(':', '')
                    safe_name = ''.join(c for c in safe_name if c.isalnum() or c in '-_')
                    desktop_path = os.path.expanduser(f"~/.local/share/applications/tick-{safe_name}.desktop")
                
                # Vérifier si existe déjà
                if os.path.exists(desktop_path):
                    print(f"[Toggle Desktop] .desktop existe déjà : {desktop_path}")
                    return
                
                # Créer le fichier
                desktop_content = f"""[Desktop Entry]
Version=1.0
Type=Application
Name={game['name']}
Exec={game['shortcut_path']}
Icon={game.get('icon_path', 'applications-games')}
Categories=Game;
Terminal=false
"""
                Path(desktop_path).write_text(desktop_content)
                os.chmod(desktop_path, 0o755)
                
                # Mettre à jour la DB
                conn = sqlite3.connect(self.db.db_path)
                cursor = conn.cursor()
                cursor.execute("UPDATE games SET desktop_path = ? WHERE id = ?", (desktop_path, game_id))
                conn.commit()
                conn.close()
                
                print(f"[Toggle Desktop] ✓ Créé : {desktop_path}")
            else:
                # Supprimer .desktop
                desktop_path = game.get('desktop_path')
                if desktop_path and os.path.exists(desktop_path):
                    os.remove(desktop_path)
                    print(f"[Toggle Desktop] ✓ Supprimé : {desktop_path}")
                    
                    # IMPORTANT : Mettre à jour la DB !
                    conn = sqlite3.connect(self.db.db_path)
                    cursor = conn.cursor()
                    cursor.execute("UPDATE games SET desktop_path = NULL WHERE id = ?", (game_id,))
                    conn.commit()
                    conn.close()
                else:
                    print(f"[Toggle Desktop] .desktop n'existe pas")
        
        except Exception as e:
            print(f"[Toggle Desktop] Erreur: {e}")
            import traceback
            traceback.print_exc()
    
    def regenerate_selected_game(self):
        """Régénère tous les fichiers d'un jeu (répare les problèmes)"""
        game_id = self.get_selected_game_id()
        if not game_id:
            QMessageBox.warning(self, "Erreur", "Sélectionne un jeu.")
            return
        
        game = self.db.get_game_by_id(game_id)
        if not game:
            return
        
        reply = QMessageBox.question(
            self, "Régénérer",
            f"Régénérer tous les fichiers de '{game['name']}' ?\n\n"
            "Ceci va recréer :\n"
            "• Le script de lancement (.sh)\n"
            "• Le fichier .desktop (si activé)\n"
            "• Le raccourci Steam (si activé)\n"
            "• Les artworks Steam\n\n"
            "Utile pour réparer les problèmes.",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply != QMessageBox.Yes:
            return
        
        try:
            # TODO: Implémenter la régénération complète
            # Pour l'instant, juste re-télécharger les artworks
            
            # Re-télécharger artworks si dans Steam
            if game.get('steam_added', 0):
                api_key = self._get_api_key()
                if api_key:
                    from steam_artwork import SteamArtworkManager
                    artwork_manager = SteamArtworkManager(api_key)
                    
                    steam_manager = SteamShortcutsManager()
                    shortcut = {
                        'exe': game['shortcut_path'],
                        'appname': game['name']
                    }
                    app_id = steam_manager._generate_app_id(shortcut, game['name'])
                    
                    if app_id < 0:
                        app_id_unsigned = app_id + 0x100000000
                    else:
                        app_id_unsigned = app_id
                    
                    artwork_manager.download_all_artwork(game['name'], app_id_unsigned)
            
            QMessageBox.information(
                self, "Régénéré",
                f"✓ '{game['name']}' a été régénéré !\n\n"
                "Si des problèmes persistent, essayez de supprimer\n"
                "et recréer le jeu complètement."
            )
            
            self.refresh_games()
        
        except Exception as e:
            QMessageBox.critical(
                self, "Erreur",
                f"Erreur lors de la régénération:\n{e}"
            )
    
    def get_selected_game_id(self) -> Optional[int]:
        """Récupère l'ID du jeu sélectionné"""
        selected = self.table.selectedItems()
        if not selected:
            return None
        row = selected[0].row()
        id_item = self.table.item(row, 0)
        return int(id_item.text()) if id_item else None
    
    def redownload_artworks(self):
        """Re-télécharge les artworks pour le jeu sélectionné"""
        game_id = self.get_selected_game_id()
        if not game_id:
            QMessageBox.warning(self, "Erreur", "Sélectionne un jeu.")
            return
        
        game = self.db.get_game_by_id(game_id)
        if not game:
            return
        
        # Récupérer la clé API
        api_key = self._get_api_key()
        if not api_key:
            return
        
        try:
            from steam_artwork import SteamArtworkManager
            artwork_manager = SteamArtworkManager(api_key)
            
            # Générer l'AppID Steam (unsigned pour artworks)
            steam_manager = SteamShortcutsManager()
            shortcut = {
                'exe': game['shortcut_path'],
                'appname': game['name']
            }
            app_id = steam_manager._generate_app_id(shortcut, game['name'])
            
            # Convertir en unsigned pour artworks
            if app_id < 0:
                app_id_unsigned = app_id + 0x100000000
            else:
                app_id_unsigned = app_id
            
            # Télécharger
            results = artwork_manager.download_all_artwork(game['name'], app_id_unsigned)
            
            downloaded = sum(1 for r in results.values() if r)
            total = len(results)
            
            QMessageBox.information(
                self, "Artworks",
                f"✓ {downloaded}/{total} artwork(s) téléchargé(s) pour '{game['name']}'"
            )
        
        except Exception as e:
            QMessageBox.critical(
                self, "Erreur",
                f"Erreur lors du téléchargement des artworks:\n{e}"
            )
    
    def launch_selected_game(self):
        """Lance le jeu sélectionné"""
        game_id = self.get_selected_game_id()
        if not game_id:
            QMessageBox.warning(self, "Erreur", "Sélectionne un jeu à lancer.")
            return
        
        game = self.db.get_game_by_id(game_id)
        if not game:
            QMessageBox.warning(self, "Erreur", "Jeu introuvable dans la base de données.")
            return
        
        shortcut = game['shortcut_path']
        if not shortcut or not os.path.exists(shortcut):
            QMessageBox.warning(
                self, "Erreur", 
                f"Le raccourci n'existe pas:\n{shortcut}"
            )
            return
        
        try:
            subprocess.Popen([shortcut], start_new_session=True)
            self.db.update_play_stats(game_id)
            QMessageBox.information(
                self, "Lancé", 
                f"{game['name']} a été lancé !"
            )
            self.refresh_games()
        except Exception as e:
            QMessageBox.critical(
                self, "Erreur de lancement", 
                f"Impossible de lancer le jeu:\n{e}"
            )
    
    def remove_from_steam_only(self):
        """Retire le jeu de Steam uniquement (garde dans T.I.C.K)"""
        game_id = self.get_selected_game_id()
        if not game_id:
            QMessageBox.warning(self, "Erreur", "Sélectionne un jeu.")
            return
        
        game = self.db.get_game_by_id(game_id)
        if not game:
            return
        
        if not game.get('steam_added', 0):
            QMessageBox.information(
                self, "Info",
                f"'{game['name']}' n'est pas dans Steam."
            )
            return
        
        reply = QMessageBox.question(
            self, "Retirer de Steam",
            f"Retirer '{game['name']}' de Steam ?\n\n"
            "Le raccourci T.I.C.K sera conservé.\n"
            "Vous pourrez le ré-ajouter à Steam plus tard.",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            try:
                if self.steam_manager.remove_shortcut(game['name']):
                    # Mettre à jour la DB
                    self.db.mark_as_added_to_steam(game_id, False)
                    
                    QMessageBox.information(
                        self, "Retiré de Steam",
                        f"✓ '{game['name']}' a été retiré de Steam\n\n"
                        "⚠️ Redémarrez Steam pour voir le changement"
                    )
                    self.refresh_games()
                else:
                    QMessageBox.warning(
                        self, "Erreur",
                        "Impossible de retirer le jeu de Steam.\n"
                        "Le raccourci n'a peut-être pas été trouvé."
                    )
            
            except Exception as e:
                QMessageBox.critical(
                    self, "Erreur",
                    f"Erreur lors du retrait de Steam:\n{e}"
                )
    
    def delete_selected_game(self):
        """Supprime le jeu sélectionné"""
        game_id = self.get_selected_game_id()
        if not game_id:
            QMessageBox.warning(self, "Erreur", "Sélectionne un jeu à supprimer.")
            return
        
        game = self.db.get_game_by_id(game_id)
        if not game:
            return
        
        # Message de confirmation avec info Steam
        msg = f"Supprimer '{game['name']}' ?\n\n"
        msg += "Ceci supprimera :\n"
        msg += "• Le raccourci T.I.C.K (fichiers .sh et .desktop)\n"
        
        if game.get('steam_added', 0) and STEAM_SUPPORT and self.steam_manager:
            msg += "• Le raccourci de Steam\n"
        
        msg += "\n⚠️ Le jeu restera installé dans Bottles"
        
        reply = QMessageBox.question(
            self, "Confirmer la suppression",
            msg,
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            # Supprimer de Steam d'abord (si ajouté)
            removed_from_steam = False
            if game.get('steam_added', 0) and STEAM_SUPPORT and self.steam_manager:
                try:
                    removed_from_steam = self.steam_manager.remove_shortcut(game['name'])
                    if removed_from_steam:
                        print(f"[T.I.C.K] ✓ Jeu supprimé de Steam")
                except Exception as e:
                    print(f"[T.I.C.K] Erreur suppression Steam: {e}")
            
            # Supprimer de T.I.C.K
            if self.db.delete_game(game_id):
                result_msg = f"✓ '{game['name']}' a été supprimé de T.I.C.K"
                
                if removed_from_steam:
                    result_msg += "\n✓ Supprimé de Steam"
                    result_msg += "\n\n⚠️ Redémarrez Steam pour voir le changement"
                elif game.get('steam_added', 0):
                    result_msg += "\n\n⚠️ Impossible de supprimer de Steam"
                    result_msg += "\nVous devrez le supprimer manuellement dans Steam"
                
                QMessageBox.information(self, "Supprimé", result_msg)
                self.refresh_games()
            else:
                QMessageBox.warning(self, "Erreur", "Impossible de supprimer le jeu.")
    
    def add_to_steam(self):
        """Ajoute le jeu sélectionné à Steam"""
        if not STEAM_SUPPORT or not self.steam_manager:
            QMessageBox.warning(
                self, "Non disponible",
                "Le support Steam n'est pas disponible.\n"
                "Vérifiez que steam_shortcuts.py est présent."
            )
            return
        
        if not self.steam_manager.is_available():
            QMessageBox.warning(
                self, "Steam introuvable",
                "Steam n'a pas été détecté sur votre système.\n"
                "Assurez-vous que Steam est installé."
            )
            return
        
        # Vérifier si Steam est en cours d'exécution
        if self.steam_manager.is_steam_running():
            reply = QMessageBox.warning(
                self, "Steam en cours d'exécution",
                "⚠️ Steam est actuellement en cours d'exécution.\n\n"
                "Pour que les modifications soient prises en compte, "
                "vous devez fermer Steam complètement puis le redémarrer.\n\n"
                "Voulez-vous continuer ?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
        
        game_id = self.get_selected_game_id()
        if not game_id:
            QMessageBox.warning(self, "Erreur", "Sélectionne un jeu à ajouter.")
            return
        
        game = self.db.get_game_by_id(game_id)
        if not game:
            QMessageBox.warning(self, "Erreur", "Jeu introuvable.")
            return
        
        # Vérifier si déjà ajouté
        if game.get('steam_added', 0):
            reply = QMessageBox.question(
                self, "Déjà ajouté",
                f"'{game['name']}' semble déjà avoir été ajouté à Steam.\n\n"
                "Voulez-vous l'ajouter à nouveau ?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
        
        shortcut_path = game['shortcut_path']
        if not shortcut_path or not os.path.exists(shortcut_path):
            QMessageBox.warning(
                self, "Erreur",
                f"Le raccourci n'existe pas:\n{shortcut_path}"
            )
            return
        
        # Préparer les paramètres
        icon_path = game.get('icon_path', "")
        if not icon_path or not os.path.exists(icon_path):
            if ICON_PATH.exists():
                icon_path = str(ICON_PATH)
        
        # Utiliser le dossier du script comme répertoire de démarrage
        start_dir = os.path.dirname(shortcut_path)
        
        # Ajouter à Steam
        try:
            success = self.steam_manager.add_shortcut(
                name=game['name'],
                exe_path=shortcut_path,
                start_dir=start_dir,
                icon_path=icon_path,
                launch_options="",
                allow_desktop_config=True,  # Important pour Steam Input!
                allow_overlay=True,
                tags=["T.I.C.K", "Bottles", "Windows", game['bottle_name']]
            )
            
            if success:
                # Marquer comme ajouté dans la DB
                self.db.mark_as_added_to_steam(game_id, True)
                
                msg = f"✓ '{game['name']}' a été ajouté à Steam!\n\n"
                if self.steam_manager.is_steam_running():
                    msg += "⚠️ Redémarrez Steam complètement pour voir le jeu.\n\n"
                msg += "Le jeu apparaîtra dans votre bibliothèque Steam avec:\n"
                msg += f"• Steam Input activé (configuration manette)\n"
                msg += f"• Overlay Steam disponible\n"
                msg += f"• Tags: T.I.C.K, Bottles, {game['bottle_name']}"
                
                QMessageBox.information(self, "Succès", msg)
                self.refresh_games()
            else:
                QMessageBox.critical(
                    self, "Erreur",
                    "Impossible d'ajouter le jeu à Steam.\n"
                    "Consultez les logs pour plus de détails."
                )
        
        except Exception as e:
            QMessageBox.critical(
                self, "Erreur",
                f"Erreur lors de l'ajout à Steam:\n{e}"
            )
    
    def extract_icons_batch(self):
        """Extrait les icônes de tous les jeux sans icône"""
        if not ICON_EXTRACTION_SUPPORT:
            QMessageBox.warning(
                self, "Non disponible",
                "L'extraction d'icônes n'est pas disponible.\n"
                "Installez icoutils (wrestool, icotool)."
            )
            return
        
        games = self.db.get_all_games()
        games_without_icon = [g for g in games if not g.get('icon_path') or not os.path.exists(g.get('icon_path', ''))]
        
        if not games_without_icon:
            QMessageBox.information(
                self, "Aucun jeu",
                "Tous vos jeux ont déjà une icône !"
            )
            return
        
        reply = QMessageBox.question(
            self, "Extraire les icônes",
            f"Extraire les icônes de {len(games_without_icon)} jeu(x) ?\n\n"
            "Cela peut prendre quelques secondes par jeu.",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply != QMessageBox.Yes:
            return
        
        # Créer une progress dialog
        progress = QProgressDialog("Extraction des icônes...", "Annuler", 0, len(games_without_icon), self)
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)
        
        icon_extractor = IconExtractor()
        extracted_count = 0
        
        for i, game in enumerate(games_without_icon):
            if progress.wasCanceled():
                break
            
            progress.setValue(i)
            progress.setLabelText(f"Extraction: {game['name']}...")
            QApplication.processEvents()
            
            try:
                icon_path = icon_extractor.extract_icon(game['exe_path'], size=256)
                if icon_path:
                    # Mettre à jour la DB
                    conn = sqlite3.connect(self.db.db_path)
                    cursor = conn.cursor()
                    cursor.execute("UPDATE games SET icon_path = ? WHERE id = ?", (icon_path, game['id']))
                    conn.commit()
                    conn.close()
                    
                    extracted_count += 1
                    
                    # Mettre à jour les fichiers .desktop si existants
                    if game.get('desktop_path') and os.path.exists(game['desktop_path']):
                        try:
                            desktop_content = Path(game['desktop_path']).read_text()
                            # Remplacer la ligne Icon=
                            import re
                            desktop_content = re.sub(
                                r'^Icon=.*$',
                                f'Icon={icon_path}',
                                desktop_content,
                                flags=re.MULTILINE
                            )
                            Path(game['desktop_path']).write_text(desktop_content)
                        except Exception as e:
                            print(f"Erreur mise à jour .desktop: {e}")
            
            except Exception as e:
                print(f"Erreur extraction icône pour {game['name']}: {e}")
        
        progress.setValue(len(games_without_icon))
        
        self.refresh_games()
        
        QMessageBox.information(
            self, "Terminé",
            f"Icônes extraites: {extracted_count}/{len(games_without_icon)}"
        )
        """Ajoute le jeu sélectionné à Steam"""
        if not STEAM_SUPPORT or not self.steam_manager:
            QMessageBox.warning(
                self, "Non disponible",
                "Le support Steam n'est pas disponible.\n"
                "Vérifiez que steam_shortcuts.py est présent."
            )
            return
        
        if not self.steam_manager.is_available():
            QMessageBox.warning(
                self, "Steam introuvable",
                "Steam n'a pas été détecté sur votre système.\n"
                "Assurez-vous que Steam est installé."
            )
            return
        
        # Vérifier si Steam est en cours d'exécution
        if self.steam_manager.is_steam_running():
            reply = QMessageBox.warning(
                self, "Steam en cours d'exécution",
                "⚠️ Steam est actuellement en cours d'exécution.\n\n"
                "Pour que les modifications soient prises en compte, "
                "vous devez fermer Steam complètement puis le redémarrer.\n\n"
                "Voulez-vous continuer ?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
        
        game_id = self.get_selected_game_id()
        if not game_id:
            QMessageBox.warning(self, "Erreur", "Sélectionne un jeu à ajouter.")
            return
        
        game = self.db.get_game_by_id(game_id)
        if not game:
            QMessageBox.warning(self, "Erreur", "Jeu introuvable.")
            return
        
        # Vérifier si déjà ajouté
        if game.get('steam_added', 0):
            reply = QMessageBox.question(
                self, "Déjà ajouté",
                f"'{game['name']}' semble déjà avoir été ajouté à Steam.\n\n"
                "Voulez-vous l'ajouter à nouveau ?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
        
        shortcut_path = game['shortcut_path']
        if not shortcut_path or not os.path.exists(shortcut_path):
            QMessageBox.warning(
                self, "Erreur",
                f"Le raccourci n'existe pas:\n{shortcut_path}"
            )
            return
        
        # Préparer les paramètres
        icon_path = ""
        if ICON_PATH.exists():
            icon_path = str(ICON_PATH)
        
        # Utiliser le dossier du script comme répertoire de démarrage
        start_dir = os.path.dirname(shortcut_path)
        
        # Ajouter à Steam
        try:
            success = self.steam_manager.add_shortcut(
                name=game['name'],
                exe_path=shortcut_path,
                start_dir=start_dir,
                icon_path=icon_path,
                launch_options="",
                allow_desktop_config=True,  # Important pour Steam Input!
                allow_overlay=True,
                tags=["T.I.C.K", "Bottles", "Windows", game['bottle_name']]
            )
            
            if success:
                # Marquer comme ajouté dans la DB
                self.db.mark_as_added_to_steam(game_id, True)
                
                msg = f"✓ '{game['name']}' a été ajouté à Steam!\n\n"
                if self.steam_manager.is_steam_running():
                    msg += "⚠️ Redémarrez Steam complètement pour voir le jeu.\n\n"
                msg += "Le jeu apparaîtra dans votre bibliothèque Steam avec:\n"
                msg += f"• Steam Input activé (configuration manette)\n"
                msg += f"• Overlay Steam disponible\n"
                msg += f"• Tags: T.I.C.K, Bottles, {game['bottle_name']}"
                
                QMessageBox.information(self, "Succès", msg)
                self.refresh_games()
            else:
                QMessageBox.critical(
                    self, "Erreur",
                    "Impossible d'ajouter le jeu à Steam.\n"
                    "Consultez les logs pour plus de détails."
                )
        
        except Exception as e:
            QMessageBox.critical(
                self, "Erreur",
                f"Erreur lors de l'ajout à Steam:\n{e}"
            )


# ---------------------------
# Main Application
# ---------------------------

class TickApp(QWidget):
    def __init__(self):
        super().__init__()
        self.db = GameDatabase()
        self.setWindowTitle("T.I.C.K – Target Input Compatible Kickoff")
        self.resize(550, 800)  # Taille confortable : 550×800
        self.setMinimumSize(500, 700)  # Minimum : 500×700
        
        # Config
        self.config_dir = Path.home() / ".config" / "tick"
        self.config_file = self.config_dir / "config.json"
        
        self._shortcut_created = False
        self._search_stop = threading.Event()
        self._search_done = False
        self._search_results = []
        self._poll_timer: QTimer | None = None
        self._current_game_id = None
        
        self._init_ui()
        self._load_bottles()
        self._update_controls_enabled()
    
    def _load_config(self) -> Dict:
        """Charge la configuration depuis le fichier JSON"""
        if not self.config_file.exists():
            return {}
        
        try:
            import json
            with open(self.config_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"[Config] Erreur lecture config: {e}")
            return {}
    
    def _save_config(self, config: Dict):
        """Sauvegarde la configuration dans le fichier JSON"""
        try:
            import json
            self.config_dir.mkdir(parents=True, exist_ok=True)
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
            print(f"[Config] Configuration sauvegardée")
        except Exception as e:
            print(f"[Config] Erreur sauvegarde config: {e}")
    
    def _get_api_key(self) -> Optional[str]:
        """Récupère la clé API (depuis config ou demande à l'user)"""
        # Essayer de charger depuis config
        config = self._load_config()
        api_key = config.get('steamgriddb_api_key')
        
        if api_key:
            return api_key
        
        # Demander à l'utilisateur
        from PySide6.QtWidgets import QInputDialog
        
        api_key, ok = QInputDialog.getText(
            self, "SteamGridDB API Key",
            "Entrez votre clé API SteamGridDB:\n"
            "(Gratuit sur https://www.steamgriddb.com/profile/preferences/api)\n\n"
            "Cette clé sera sauvegardée pour les prochaines fois.",
            QLineEdit.Normal
        )
        
        if ok and api_key:
            api_key = api_key.strip()
            # Sauvegarder dans config
            config['steamgriddb_api_key'] = api_key
            self._save_config(config)
            return api_key
        
        return None
    
    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        
        # Header
        header_pm = make_header_pixmap()
        header_label = QLabel()
        header_label.setPixmap(header_pm)
        header_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header_label)
        
        # Tabs
        self.tabs = QTabWidget()
        
        # Tab 1: Créer un raccourci
        create_tab = QWidget()
        self._init_create_tab(create_tab)
        self.tabs.addTab(create_tab, "➕ Nouveau jeu")
        
        # Tab 2: Raccourcis créés
        self.library_tab = GameLibraryTab(self.db)
        self.tabs.addTab(self.library_tab, "🔗 Raccourcis créés")
        
        main_layout.addWidget(self.tabs)
    
    def _init_create_tab(self, parent):
        layout = QVBoxLayout(parent)
        layout.setSpacing(8)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Check Bottles
        if not bottles_cli_exists():
            warn = QLabel(
                "<b style='color: red;'>⚠ bottles-cli introuvable</b><br>"
                "Assure-toi que Bottles est bien installé."
            )
            layout.addWidget(warn)
            return
        
        # Ligne 1: Lanceur + Nom du jeu (côte à côte)
        top_row = QHBoxLayout()
        top_row.setSpacing(5)
        
        # Lanceur
        self.btn_reload_bottles = QPushButton("🔄")
        self.btn_reload_bottles.setMaximumWidth(35)
        self.btn_reload_bottles.setToolTip("Recharger les lanceurs")
        self.btn_reload_bottles.clicked.connect(self._load_bottles)
        top_row.addWidget(self.btn_reload_bottles)
        
        self.bottle_combo = QComboBox()
        self.bottle_combo.setEditable(False)
        self.bottle_combo.currentIndexChanged.connect(self._on_launcher_changed)
        self.bottle_combo.setMinimumWidth(180)
        top_row.addWidget(self.bottle_combo)
        
        # Nom du jeu (avec recherche automatique)
        self.game_name = QLineEdit()
        self.game_name.setPlaceholderText("Rechercher le jeu (3+ lettres)")
        self.game_name.textChanged.connect(self._on_game_name_changed)
        top_row.addWidget(self.game_name, 1)
        
        # Petit cadre pour l'icône extraite
        self.icon_preview = QLabel()
        self.icon_preview.setFixedSize(32, 32)
        self.icon_preview.setStyleSheet("border: 1px solid #ccc; background: #f0f0f0;")
        self.icon_preview.setScaledContents(True)
        self.icon_preview.setVisible(False)
        top_row.addWidget(self.icon_preview)
        
        self.btn_debug_bottles = QPushButton("⚙️")
        self.btn_debug_bottles.setMaximumWidth(35)
        self.btn_debug_bottles.setToolTip("Debug")
        self.btn_debug_bottles.clicked.connect(self._show_bottles_debug)
        top_row.addWidget(self.btn_debug_bottles)
        
        layout.addLayout(top_row)
        
        # Timer pour recherche automatique (debounce 800ms)
        self._search_timer = QTimer()
        self._search_timer.setSingleShot(True)
        self._search_timer.timeout.connect(self._auto_search_exe)
        
        # Ligne 2: Exe du jeu
        exe_layout = QHBoxLayout()
        exe_layout.setSpacing(5)
        
        # Bouton "+X" à gauche
        # Bouton "+N ▼" supprimé - inutile pour l'UX
        exe_layout.addStretch()  # Espace flexible à la place
        
        self.exe_combo = QComboBox()
        self.exe_combo.setEditable(True)
        self.exe_combo.lineEdit().setPlaceholderText(".exe du jeu")
        exe_layout.addWidget(self.exe_combo, 1)
        
        self.btn_browse_exe = QPushButton("📂")
        self.btn_browse_exe.setMaximumWidth(35)
        self.btn_browse_exe.setToolTip("Aller à…")
        self.btn_browse_exe.clicked.connect(self.browse_exe_manually)
        exe_layout.addWidget(self.btn_browse_exe)
        
        layout.addLayout(exe_layout)
        
        # Séparateur
        layout.addSpacing(10)
        
        # Seule option : Steam
        if STEAM_SUPPORT:
            self.add_to_steam_check = QCheckBox("Ajouter à Steam")
            self.add_to_steam_check.setChecked(False)
            self.add_to_steam_check.toggled.connect(self._on_steam_check_toggled)
            layout.addWidget(self.add_to_steam_check)
            
            # Option artwork (sous-option de Steam)
            if ARTWORK_SUPPORT:
                self.download_artwork_check = QCheckBox("  └─ Télécharger les artworks (bannières, logos)")
                self.download_artwork_check.setChecked(True)
                self.download_artwork_check.setEnabled(False)
                self.download_artwork_check.setStyleSheet("margin-left: 20px;")
                layout.addWidget(self.download_artwork_check)
        
        # Info extraction icônes (si indisponible)
        if ICON_EXTRACTION_SUPPORT:
            icon_extractor_test = IconExtractor()
            if not icon_extractor_test.is_available():
                icon_warn = QLabel("<small>ℹ️ icoutils non installé (pas d'extraction d'icône)</small>")
                icon_warn.setStyleSheet("color: #888;")
                layout.addWidget(icon_warn)
        
        # Séparateur
        layout.addSpacing(10)
        
        # Affichage du jeu créé (Nom + Icône)
        game_info_group = QGroupBox("Jeu créé")
        # Pas de contrainte de hauteur, laisse Qt gérer
        game_info_layout = QHBoxLayout()
        game_info_layout.setSpacing(10)
        
        # Icône du jeu (plus grande)
        self.created_game_icon = QLabel()
        self.created_game_icon.setFixedSize(48, 48)
        self.created_game_icon.setStyleSheet("border: 2px solid #4CAF50; background: white; border-radius: 4px;")
        self.created_game_icon.setScaledContents(True)
        self.created_game_icon.setVisible(False)
        game_info_layout.addWidget(self.created_game_icon)
        
        # Nom + chemin
        game_text_layout = QVBoxLayout()
        game_text_layout.setSpacing(2)
        
        self.created_game_name = QLabel()
        self.created_game_name.setStyleSheet("font-weight: bold; font-size: 13px; color: #2E7D32;")
        game_text_layout.addWidget(self.created_game_name)
        
        self.shortcut_path = QLineEdit()
        self.shortcut_path.setReadOnly(True)
        self.shortcut_path.setPlaceholderText("Chemin du script .sh")
        self.shortcut_path.setMaximumHeight(24)
        self.shortcut_path.setStyleSheet("font-size: 10px; color: #666;")
        game_text_layout.addWidget(self.shortcut_path)
        
        game_info_layout.addLayout(game_text_layout, 1)
        game_info_group.setLayout(game_info_layout)
        game_info_group.setVisible(False)  # Caché jusqu'à création
        self.game_info_group = game_info_group
        layout.addWidget(game_info_group)
        
        # Séparateur
        layout.addSpacing(5)
        
        # Bouton principal
        self.btn_create = QPushButton("🔨 Créer le raccourci")
        self.btn_create.setMinimumHeight(40)
        self.btn_create.clicked.connect(self._on_main_button_clicked)
        layout.addWidget(self.btn_create)
        
        # Résumé (simple, toujours visible mais discret)
        self.output_display = QTextEdit()
        self.output_display.setReadOnly(True)
        self.output_display.setFixedHeight(260)  # Équilibré
        self.output_display.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)  # Pas de scrollbar
        self.output_display.setStyleSheet("background: #f9f9f9; border: 1px solid #ddd; font-size: 11px;")
        self._set_output_intro()
        layout.addWidget(self.output_display)
        
        # Petit espace entre récap et bouton (pas de stretch)
        layout.addSpacing(15)
        
        # Bouton reset/fermer (discret)
        reset_layout = QHBoxLayout()
        reset_layout.addStretch()
        self.btn_reset = QPushButton("🔄 Réinitialiser")
        self.btn_reset.setMaximumWidth(150)
        self.btn_reset.clicked.connect(self.reset_state)
        reset_layout.addWidget(self.btn_reset)
        layout.addLayout(reset_layout)
    
    def _load_bottles(self):
        bottles = list_bottles()
        self.bottle_combo.clear()
        self.bottle_combo.addItem("-- Choisis un lanceur --", None)
        for b in bottles:
            self.bottle_combo.addItem(b, b)
    
    def _current_launcher(self) -> str | None:
        return self.bottle_combo.currentData()
    
    def _is_launcher_selected(self) -> bool:
        return self._current_launcher() is not None
    
    def _current_exe_text(self) -> str:
        if self.exe_combo.lineEdit():
            return self.exe_combo.lineEdit().text().strip()
        return self.exe_combo.currentText().strip()
    
    def _set_exe_text(self, text: str):
        if self.exe_combo.lineEdit():
            self.exe_combo.lineEdit().setText(text)
        else:
            self.exe_combo.setEditText(text)
    
    def _clear_exe_list(self):
        self.exe_combo.blockSignals(True)
        self.exe_combo.clear()
        self.exe_combo.blockSignals(False)
        self._set_more_button(0)
    
    def _set_more_button(self, extra_count: int):
        # Méthode désactivée - bouton "+N" supprimé
        pass
    
    def _select_exe_from_menu(self, exe_path: str):
        """Sélectionne un exe depuis le menu déroulant"""
        self._set_exe_text(exe_path)
        
        # Auto-remplir le nom si vide
        if not self.game_name.text().strip():
            try:
                extractor = GameInfoExtractor()
                name = extractor.extract_game_name(exe_path)
                self.game_name.setText(name)
                
                # Afficher l'icône si extraite
                self._update_icon_preview(exe_path)
            except:
                self.game_name.setText(Path(exe_path).stem)
    
    def _update_icon_preview(self, exe_path: str):
        """Affiche l'icône extraite dans le petit cadre"""
        if not ICON_EXTRACTION_SUPPORT or not hasattr(self, 'icon_preview'):
            return
        
        try:
            icon_extractor = IconExtractor()
            if icon_extractor.is_available():
                icon_path = icon_extractor.extract_icon(exe_path, size=32)
                if icon_path and os.path.exists(icon_path):
                    pixmap = QPixmap(icon_path)
                    self.icon_preview.setPixmap(pixmap)
                    self.icon_preview.setVisible(True)
                    return
        except:
            pass
        
        self.icon_preview.setVisible(False)
    
    def _set_output_intro(self):
        self.output_display.setHtml(
            "<p style='color: #666;'>"
            "Remplis les champs ci-dessus, puis clique sur « Créer le raccourci » "
            "pour générer un script shell et (optionnellement) un fichier .desktop."
            "</p>"
        )
    
    def _set_output_created(self, name, bottle, exe, win_path, shortcut, outdir):
        escaped_name = html_escape(name)
        escaped_bottle = html_escape(bottle)
        escaped_exe = html_escape(exe)
        escaped_win = html_escape(win_path)
        escaped_sh = html_escape(shortcut)
        escaped_out = html_escape(outdir)
        
        desktop_info = ""
        if self._current_desktop_path:
            escaped_desktop = html_escape(self._current_desktop_path)
            desktop_info = f"<li><b>Fichier .desktop:</b> <code>{escaped_desktop}</code></li>"
        
        self.output_display.setHtml(f"""
        <p><b style='color: green;'>✔ Raccourci créé avec succès!</b></p>
        <ul>
          <li><b>Jeu:</b> {escaped_name}</li>
          <li><b>Lanceur:</b> {escaped_bottle}</li>
          <li><b>Exe Linux:</b> <code>{escaped_exe}</code></li>
          <li><b>Exe Windows:</b> <code>{escaped_win}</code></li>
          <li><b>Script shell:</b> <code>{escaped_sh}</code></li>
          {desktop_info}
          <li><b>Dossier:</b> <code>{escaped_out}</code></li>
        </ul>
        <p>Tu peux maintenant ajouter <code>{escaped_sh}</code> comme jeu non-Steam dans Steam!</p>
        """)
    
    def _update_controls_enabled(self):
        launcher_ok = self._is_launcher_selected()
        self.exe_combo.setEnabled(launcher_ok)
        self.btn_browse_exe.setEnabled(launcher_ok)
        # Bouton exe_more supprimé
        
        if not launcher_ok:
            self.btn_create.setEnabled(False)
        else:
            self._update_create_button_state()
    
    def _update_create_button_state(self):
        if not self._is_launcher_selected():
            self.btn_create.setEnabled(False)
            return
        exe = self._current_exe_text()
        valid = bool(exe) and exe.lower().endswith(".exe") and Path(exe).is_file()
        self.btn_create.setEnabled(True if self._shortcut_created else valid)
    
    def _search_ui_begin(self):
        # Plus de bouton search à modifier (recherche automatique)
        pass
    
    def _search_ui_end(self):
        # Plus de bouton search à modifier (recherche automatique)
        pass
    
    def _set_main_button_to_create(self):
        self._shortcut_created = False
        self.btn_create.setText("🔨 Créer le raccourci")
        self.btn_create.setVisible(True)  # Réafficher le bouton
        self._update_create_button_state()
    
    def _set_main_button_to_copy(self):
        self._shortcut_created = True
        # Cacher le bouton (on a déjà "Fermer")
        self.btn_create.setVisible(False)
    
    def _on_main_button_clicked(self):
        if self._shortcut_created:
            self.copy_shortcut_path()
        else:
            self.create_shortcut()
    
    def reset_state(self):
        # Arrêter la recherche en cours
        try:
            if hasattr(self, '_search_stop'):
                self._search_stop.set()
        except Exception:
            pass
        
        if self._poll_timer:
            self._poll_timer.stop()
            self._poll_timer = None
        
        # Réinitialiser les états
        self._search_stop = threading.Event()
        self._search_done = False
        self._search_results = []
        
        self.bottle_combo.setCurrentIndex(0)
        self.game_name.clear()
        self._clear_exe_list()
        self.shortcut_path.clear()
        self._search_ui_end()
        self._update_controls_enabled()
        self._set_main_button_to_create()
        self._set_output_intro()
        self._current_game_id = None
        
        # Cacher l'affichage du jeu créé
        if hasattr(self, 'game_info_group'):
            self.game_info_group.setVisible(False)
            self.created_game_icon.setVisible(False)
        
        # Cacher l'icône preview
        if hasattr(self, 'icon_preview'):
            self.icon_preview.setVisible(False)
        
        # Remettre le texte du bouton
        self.btn_reset.setText("🔄 Réinitialiser")
    
    def _on_launcher_changed(self):
        bottle = self._current_launcher()
        guessed = guess_bottle_drive_c(bottle) if bottle else None
        if self.exe_combo.lineEdit():
            self.exe_combo.lineEdit().setPlaceholderText(guessed or "")
        self._clear_exe_list()
        self.shortcut_path.clear()
        self._set_main_button_to_create()
        self._update_controls_enabled()
    
    def _on_steam_check_toggled(self, checked: bool):
        """Active/désactive l'option de téléchargement d'artworks"""
        if hasattr(self, 'download_artwork_check'):
            self.download_artwork_check.setEnabled(checked)
    
    def _on_game_name_changed(self, text: str):
        """Déclenche une recherche automatique après 800ms de pause"""
        # Annuler la recherche précédente
        if hasattr(self, '_search_timer'):
            self._search_timer.stop()
        
        # Ne lancer que si 3+ caractères
        if len(text.strip()) >= 3 and self._is_launcher_selected():
            self._search_timer.start(800)  # 800ms de délai
    
    def _auto_search_exe(self):
        """Lance la recherche automatique d'exe"""
        query = self.game_name.text().strip()
        
        if not query or len(query) < 3:
            return
        
        if not self._is_launcher_selected():
            return
        
        bottle = self._current_launcher()
        drive_c = guess_bottle_drive_c(bottle)
        
        if not drive_c:
            return
        
        # Lancer la recherche en arrière-plan (silencieux)
        self._search_stop = threading.Event()
        self._search_done = False
        self._search_results = []
        
        def _worker():
            try:
                results = find_exes_in_drive_c(drive_c, query, self._search_stop)
                if not self._search_stop.is_set():
                    self._search_results = results
            except Exception as e:
                print(f"Erreur recherche: {e}")
                self._search_results = []
            finally:
                self._search_done = True
        
        threading.Thread(target=_worker, daemon=True).start()
        QTimer.singleShot(10_000, self._stop_search_after_timeout)
        
        self._poll_timer = QTimer(self)
        self._poll_timer.timeout.connect(self._poll_search_finished)
        self._poll_timer.start(120)
    
    def _show_bottles_debug(self):
        """Affiche les informations de debug sur les bouteilles"""
        bottles = list_bottles()
        
        debug_info = "=== BOTTLES DÉTECTÉES ===\n\n"
        
        if not bottles:
            debug_info += "Aucune bouteille trouvée via bottles-cli!\n\n"
        else:
            for bottle in bottles:
                debug_info += f"📦 {bottle}\n"
                drive_c = guess_bottle_drive_c(bottle)
                if drive_c:
                    debug_info += f"   ✓ drive_c: {drive_c}\n"
                    # Vérifier si on peut lister le contenu
                    try:
                        subdirs = [d for d in os.listdir(drive_c) if os.path.isdir(os.path.join(drive_c, d))]
                        debug_info += f"   Dossiers: {', '.join(subdirs[:5])}\n"
                    except:
                        debug_info += f"   Erreur: impossible de lister le contenu\n"
                else:
                    debug_info += f"   ✗ drive_c introuvable!\n"
                debug_info += "\n"
        
        # Afficher aussi les emplacements de recherche
        home = os.path.expanduser("~")
        debug_info += "=== EMPLACEMENTS RECHERCHÉS ===\n\n"
        
        search_paths = [
            ("Flatpak", os.path.join(home, ".var", "app", "com.usebottles.bottles", "data", "bottles", "bottles")),
            ("Native ~/.local", os.path.join(home, ".local", "share", "bottles", "bottles")),
            ("Native ~/.bottles", os.path.join(home, ".bottles", "bottles")),
        ]
        
        for name, path in search_paths:
            exists = "✓" if os.path.isdir(path) else "✗"
            debug_info += f"{exists} {name}:\n   {path}\n\n"
        
        # Afficher dans une boîte de dialogue avec scrolling
        msg = QMessageBox(self)
        msg.setWindowTitle("Debug Bottles")
        msg.setIcon(QMessageBox.Information)
        msg.setText("Informations de diagnostic")
        msg.setDetailedText(debug_info)
        msg.exec()
    
    def browse_exe_manually(self):
        if not self._is_launcher_selected():
            return
        bottle = self._current_launcher()
        drive_c = guess_bottle_drive_c(bottle)
        start_dir = drive_c or str(Path.home())
        
        current = self._current_exe_text()
        if current and Path(current).is_file():
            start_dir = str(Path(current).parent)
        
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Choisir l'exécutable Windows (.exe) du jeu",
            start_dir,
            "Executables Windows (*.exe);;Tous les fichiers (*)",
        )
        if not path:
            return
        self._set_exe_text(path)
        
        # Juste afficher l'icône (le nom sera détecté à la création)
        try:
            self._update_icon_preview(path)
        except:
            pass
        
        self._set_main_button_to_create()
        self._update_create_button_state()
    
    def _stop_search_after_timeout(self):
        if not self._search_done:
            self._search_stop.set()
    
    def _poll_search_finished(self):
        if not self._search_done:
            return
        if self._poll_timer:
            self._poll_timer.stop()
        
        self._search_ui_end()
        
        results = self._search_results or []
        if results:
            self.exe_combo.blockSignals(True)
            self.exe_combo.clear()
            self.exe_combo.addItems(results)
            self.exe_combo.blockSignals(False)
            self._set_exe_text(results[0])
            self._set_more_button(len(results) - 1)
            
            # Extraire l'icône en silencieux (pas le nom, on le fera à la création)
            try:
                self._update_icon_preview(results[0])
            except:
                pass
        else:
            self._set_more_button(0)
            QMessageBox.information(
                self,
                "Introuvable",
                "Aucun .exe trouvé dans ce lanceur.\n\n"
                "Tu peux utiliser le bouton « Aller à… » pour le choisir manuellement."
            )
        
        self._set_main_button_to_create()
        self._update_create_button_state()
    
    def search_exe(self):
        if not self._is_launcher_selected():
            return
        
        bottle = self._current_launcher()
        query = self.game_name.text().strip()
        if not query:
            QMessageBox.warning(self, "Erreur", "Renseigne d'abord le nom du jeu.")
            return
        
        drive_c = guess_bottle_drive_c(bottle)
        if not drive_c:
            self._set_more_button(0)
            QMessageBox.warning(
                self,
                "Introuvable",
                "Impossible de localiser le drive_c de ce lanceur.\n\n"
                "Tu peux quand même utiliser le bouton « Aller à… » pour choisir un .exe manuellement."
            )
            self._set_main_button_to_create()
            self._update_create_button_state()
            return
        
        # Arrêter toute recherche en cours
        if hasattr(self, '_search_stop'):
            self._search_stop.set()
        if self._poll_timer:
            self._poll_timer.stop()
            self._poll_timer = None
        
        self._search_ui_begin()
        
        # Réinitialiser l'état de recherche
        self._search_stop = threading.Event()
        self._search_done = False
        self._search_results = []
        
        def _worker():
            try:
                results = find_exes_in_drive_c(drive_c, query, self._search_stop)
                if not self._search_stop.is_set():
                    self._search_results = results
            except Exception as e:
                print(f"Erreur recherche: {e}")
                self._search_results = []
            finally:
                self._search_done = True
        
        threading.Thread(target=_worker, daemon=True).start()
        QTimer.singleShot(10_000, self._stop_search_after_timeout)
        
        self._poll_timer = QTimer(self)
        self._poll_timer.timeout.connect(self._poll_search_finished)
        self._poll_timer.start(120)
    
    def pick_outdir(self):
        cur = self.out_dir.text().strip() or DEFAULT_OUTDIR
        start = cur
        if not os.path.isdir(start):
            home = str(Path.home())
            fallback1 = os.path.join(home, ".local", "bin")
            start = fallback1 if os.path.isdir(fallback1) else home
        
        path = QFileDialog.getExistingDirectory(self, "Choisir le dossier des raccourcis", start)
        if not path:
            return
        self.out_dir.setText(path)
    
    def pick_desktop_dir(self):
        cur = self.desktop_dir.text().strip() or DEFAULT_DESKTOP_DIR
        start = cur if os.path.isdir(cur) else str(Path.home())
        
        path = QFileDialog.getExistingDirectory(self, "Choisir le dossier .desktop", start)
        if not path:
            return
        self.desktop_dir.setText(path)
    
    def create_shortcut(self):
        exe = self._current_exe_text()
        bottle = self._current_launcher()
        
        # Utiliser les valeurs par défaut (plus de champs configurables)
        outdir = DEFAULT_OUTDIR
        desktop_dir = DEFAULT_DESKTOP_DIR
        
        if not bottle:
            QMessageBox.warning(self, "Erreur", "Choisis un lanceur.")
            return
        if not exe or not Path(exe).is_file():
            QMessageBox.warning(self, "Erreur", "Choisis un fichier .exe valide.")
            self._update_create_button_state()
            return
        
        # DÉTECTER LE VRAI NOM DU JEU ICI !
        print(f"\n[Création] Détection du vrai nom depuis: {exe}")
        try:
            extractor = GameInfoExtractor()
            name = extractor.extract_game_name(exe)
            print(f"[Création] ✓ Nom détecté: {name}")
        except Exception as e:
            print(f"[Création] Erreur détection, fallback sur nom fichier: {e}")
            name = Path(exe).stem
        
        base_lower = Path(exe).name.lower()
        if base_lower in EXE_BLACKLIST:
            r = QMessageBox.question(
                self,
                "Avertissement",
                f"Cet exe ressemble à un composant/launcher ({base_lower}).\n"
                "Créer quand même un raccourci Steam Input ?",
                QMessageBox.Yes | QMessageBox.No,
            )
            if r != QMessageBox.Yes:
                return
        
        try:
            win_path = linux_exe_to_windows_path(exe)
        except ValueError as e:
            QMessageBox.critical(self, "Chemin non convertible", str(e))
            return
        
        ensure_dir(outdir)
        slug = slugify(name)
        date_tag = datetime.now().strftime("%Y%m%d")
        shortcut = os.path.join(outdir, f"{slug}-tick-{date_tag}.sh")
        
        content = (
            "#!/usr/bin/env bash\n"
            "set -euo pipefail\n\n"
            f'LANCEUR="{bottle}"\n'
            f"GAME_EXE='{win_path}'\n\n"
            'exec bottles-cli run -b "$LANCEUR" -e "$GAME_EXE"\n'
        )
        write_executable(shortcut, content)
        
        # Extract icon automatically (silently)
        extracted_icon_path = None
        if ICON_EXTRACTION_SUPPORT:
            try:
                icon_extractor = IconExtractor()
                if icon_extractor.is_available():
                    # Extraction silencieuse en arrière-plan
                    extracted_icon_path = icon_extractor.extract_icon(exe, size=256)
            except Exception as e:
                # Silencieux en cas d'erreur
                pass
        
        # Create .desktop file (TOUJOURS créé automatiquement)
        self._current_desktop_path = None
        try:
            desktop_path = create_desktop_file(
                name, shortcut, bottle, exe, desktop_dir,
                icon_path=extracted_icon_path
            )
            self._current_desktop_path = desktop_path
            print(f"[Création] ✓ Fichier .desktop créé: {desktop_path}")
        except Exception as e:
            print(f"[Création] ⚠️ Erreur création .desktop: {e}")
            QMessageBox.warning(
                self, "Avertissement",
                f"Le script a été créé mais le fichier .desktop a échoué:\n{e}"
            )
        
        # Save to database
        game_id = self.db.add_game(
            name=name,
            bottle_name=bottle,
            exe_path=exe,
            win_path=win_path,
            shortcut_path=shortcut,
            desktop_path=self._current_desktop_path,
            icon_path=extracted_icon_path
        )
        self._current_game_id = game_id
        
        # Add to Steam if requested
        if STEAM_SUPPORT and hasattr(self, 'add_to_steam_check') and self.add_to_steam_check.isChecked():
            steam_manager = SteamShortcutsManager()
            if steam_manager.is_available():
                try:
                    # Utiliser l'icône extraite si disponible, sinon l'icône TICK
                    icon_path = extracted_icon_path if extracted_icon_path else (str(ICON_PATH) if ICON_PATH.exists() else "")
                    start_dir = os.path.dirname(shortcut)
                    
                    steam_success = steam_manager.add_shortcut(
                        name=name,
                        exe_path=shortcut,
                        start_dir=start_dir,
                        icon_path=icon_path,
                        launch_options="",
                        allow_desktop_config=True,
                        allow_overlay=True,
                        tags=["T.I.C.K", "Bottles", "Windows", bottle]
                    )
                    
                    if steam_success:
                        self.db.mark_as_added_to_steam(game_id, True)
                        steam_msg = "\n\n🎮 Jeu ajouté à Steam avec succès!"
                        if steam_manager.is_steam_running():
                            steam_msg += "\n⚠️ Redémarrez Steam pour voir le jeu."
                        
                        # Télécharger les artworks si demandé
                        if ARTWORK_SUPPORT and hasattr(self, 'download_artwork_check') and self.download_artwork_check.isChecked():
                            try:
                                # Récupérer l'AppID généré par Steam (signé)
                                app_id = steam_manager._generate_app_id(shortcut, name)
                                
                                # IMPORTANT : Convertir en unsigned pour les noms de fichiers
                                # Steam utilise signed dans le VDF mais unsigned pour les artworks !
                                if app_id < 0:
                                    app_id_unsigned = app_id + 0x100000000  # Convertir en unsigned 32-bit
                                else:
                                    app_id_unsigned = app_id
                                
                                print(f"\n[Artworks] Téléchargement pour '{name}' (AppID: {app_id_unsigned})")
                                
                                # Récupérer la clé API (demande si nécessaire)
                                api_key = self._get_api_key()
                                
                                if api_key:
                                    artwork_manager = SteamArtworkManager(api_key=api_key)
                                    
                                    if artwork_manager.is_available():
                                        results = artwork_manager.download_all_artwork(name, app_id_unsigned)
                                        
                                        success_count = sum(1 for v in results.values() if v)
                                        if success_count > 0:
                                            steam_msg += f"\n🎨 {success_count} artwork(s) téléchargé(s) !"
                                        else:
                                            steam_msg += "\n⚠️ Aucun artwork trouvé sur SteamGridDB."
                                    else:
                                        steam_msg += "\n⚠️ Impossible d'accéder au dossier Steam."
                                else:
                                    print("[Artworks] Pas de clé API, téléchargement ignoré")
                                    steam_msg += "\n(Artworks non téléchargés)"
                            except Exception as e:
                                print(f"[Artworks] Erreur: {e}")
                                steam_msg += f"\n⚠️ Erreur téléchargement artworks: {e}"
                    else:
                        steam_msg = "\n\n⚠️ Erreur lors de l'ajout à Steam."
                    
                    self._current_desktop_path = (self._current_desktop_path or "") + steam_msg
                except Exception as e:
                    print(f"Steam add error: {e}")
        
        self.shortcut_path.setText(shortcut)
        
        # Afficher le nom + icône du jeu créé
        if hasattr(self, 'game_info_group'):
            self.created_game_name.setText(f"✓ {name}")
            
            # Afficher l'icône si disponible
            if extracted_icon_path and os.path.exists(extracted_icon_path):
                pixmap = QPixmap(extracted_icon_path)
                self.created_game_icon.setPixmap(pixmap)
                self.created_game_icon.setVisible(True)
            else:
                self.created_game_icon.setVisible(False)
            
            self.game_info_group.setVisible(True)
        self._set_output_created(name, bottle, exe, win_path, shortcut, outdir)
        self._set_main_button_to_copy()
        
        # Changer le bouton "Réinitialiser" en "Fermer" après la création
        self.btn_reset.setText("✓ Fermer")
        
        # Refresh library if visible
        if hasattr(self, 'library_tab'):
            self.library_tab.refresh_games()
    
    def copy_shortcut_path(self):
        shortcut = self.shortcut_path.text().strip()
        if not shortcut:
            QMessageBox.information(self, "Info", "Aucun raccourci à copier pour l'instant.")
            return
        QGuiApplication.clipboard().setText(shortcut)
        QMessageBox.information(self, "Copié", "Chemin du raccourci copié dans le presse-papiers.")


def main():
    app = QApplication([])
    if ICON_PATH.exists():
        app.setWindowIcon(QIcon(str(ICON_PATH)))
    w = TickApp()
    w.show()
    app.exec()


if __name__ == "__main__":
    main()
